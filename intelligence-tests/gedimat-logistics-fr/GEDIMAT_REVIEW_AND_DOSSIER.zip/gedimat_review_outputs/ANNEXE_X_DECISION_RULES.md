# Annexe X — Règles de décision
- Priorités: 1) Urgence client; 2) Proximité km; 3) Coût interne (navette)
- Seuils: ≤10 t interne; >10 t affrètement; Δ>15 km = proximité stricte
- Dérogations: urgence, contrainte fournisseur, anomalie de coût (journalisées)
