# BENCHMARK VERIFICATION RESULTS

## Case 1: Leroy Merlin 2021–2023 (Réau / “Easylog”)
**Status:** ⚠️ PARTIALLY VERIFIED
- **Croissance e‑commerce +55% (2021)** — article sectoriel : Stratégies Logistique (contexte e‑commerce 2021).  
  https://strategieslogistique.com/Comment-Leroy-Merlin-adapte-sa%2C12454
- **Projet Easylog ~40 M€ & 27 AGV STILL (site de Réau)** — confirmé par Supply Chain Magazine (NL 3628, 2022).  
  https://www.supplychainmagazine.fr/nl/2022/3628/leroy-merlin-dote-son-entrepot-automatise-de-reau-de-27-agv-still-706966.php
- **ADEO Overview 2023 (PDF accessible via site officiel)** — source corporate (contexte).  
  https://www.adeo.com/en/

**Note:** La baisse de coûts “11–15%” **n’est pas vérifiée** publiquement dans ces sources. À présenter **comme une formule calculable** après mesure de la baseline.

---

## Case 2: Kingfisher Group (NPS / Castorama)
**Status:** ⚠️ PARTIALLY VERIFIED
- **NPS suivi mensuellement au niveau Groupe (reporting Board)** — Annual Report 2022/23 (accès public).  
  https://www.kingfisher.com/investors/
- **Castorama = bannière Kingfisher** — page “Retail banners”.  
  https://www.kingfisher.com/brands/

**Note:** Ne pas fixer “NPS = 50” ni “cible = 60” sans page précise. Formuler: “NPS suivi et piloté mensuellement au niveau du Groupe”.

---

## Case 3: Saint‑Gobain / Point P (Transport Control Tower)
**Status:** ⚠️ PARTIALLY VERIFIED
- **13% CO₂ reduction & >$10M savings/5y** — étude/chronique d’ARC Advisory Group (Logistics Viewpoints, 2022) décrivant les résultats d’initiatives transport chez Saint‑Gobain.  
  https://logisticsviewpoints.com/2022/01/31/is-saint-gobain-serious-about-reducing-their-carbon-footprint/
- **Integrated Annual Report 2022/2023** — rapport intégré (contexte, pas de chiffres spécifiques sur la control tower).  
  https://www.saint-gobain.com/

**Recommandation dossiers:** garder les formulations **sourcées** ci‑dessus et convertir tous pourcentages “moyens” non prouvés en **formules**.

---

## OVERALL BENCHMARK CREDIBILITY: ⚠️ PARTIAL
Utilisables avec reformulations prudentes et références explicites.
