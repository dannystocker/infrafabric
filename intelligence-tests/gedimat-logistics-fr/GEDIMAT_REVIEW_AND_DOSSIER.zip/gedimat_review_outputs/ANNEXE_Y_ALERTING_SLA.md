# Annexe Y — Alertes & SLA
- Champs: promised_delivery_date, supplier_ack_date, customer_urgency_flag, pickup_confirmed_timestamp, depot_assigned, exception_reason
- SLA: ARC/ACK ≤48 h; pickup J‑1 16:00; respect fenêtre de livraison
- Alertes: ARC/ACK manquant; risque retard J‑1; pickup non confirmé; urgence client
- Pseudo‑requêtes SQL: cf. dossier (exemples fournis)
