# Dossier Final — Optimisation Logistique Gedimat
**Date** : 2025‑11‑17  
**Portée** : 3 dépôts, enlèvements fournisseurs non livreurs, affrètement externe vs. navette interne

---

## 1. Résumé exécutif

**Problème.** Les enlèvements chez fournisseurs “non livreurs” génèrent des **coûts d’affrètement élevés** et des **retards** perçus par les clients. Les trois dépôts défendent leurs préférences de livraison, ce qui **multiplie les affrètements** et complexifie la planification. Les alertes SI sont limitées (ARC/ACK fournisseurs, confirmation d’enlèvement transporteur). fileciteturn0file0

**Opportunité.** Standardiser le **choix du dépôt** par **proximité fournisseur** (puis navette interne), instaurer un **système d’alertes simple** (emails/règles) et **mesurer la satisfaction**. L’usage de la navette interne pour redistribuer depuis le dépôt le plus proche réduit l’affrètement externe inutile. fileciteturn0file0

**Recommandations (3 axes).**
- **Gains rapides (0–30 jours)** : (i) Activer des **alertes** ARC/ACK et enlèvement J‑1 16h ; (ii) lancer un **sondage satisfaction** (20 clients, 5 questions) ; (iii) appliquer la **règle proximité** et documenter toute dérogation.  
- **Moyen terme (30–90 jours)** : (i) **Outil scoring dépôt** (Volume, Distance, Urgence) ; (ii) **tableau de bord** de suivi (service, satisfaction, consolidation) ; (iii) revue hebdo des **exceptions**.  
- **Long terme (90+ jours)** : (i) **Standard d’affectation** SI (dépôt par km) ; (ii) contrats transporteurs avec **grilles unifiées** ; (iii) intégration des **contacts relationnels** (fournisseurs, affréteurs) dans le SI. fileciteturn0file0

**Retour sur investissement (RSI) — à formaliser par formule, pas par chiffre fixe.**  
\[ \textbf{RSI} = \frac{\text{Baseline affrètement (30 j factures)}}{\text{Investissement (temps + outils)}} \times \text{Réduction attendue (scénario)} \]  
- Scénarios : **Conservateur 8 %**, **Base 12 %**, **Haut 15 %** — issus **de cas externes publiés** et non d’estimations internes. (Voir §4 et Annexe G)

**Décision attendue.** Valider : (i) la **politique “proximité d’abord”** + dérogations limitées (3 cas), (ii) la **mise en place des alertes** minimalistes, (iii) la **mesure satisfaction** et **indicateurs** du pilote sur 30–90 jours.

**Prochaines étapes.** Démarrage sous 7 jours : **Annexe Y (Alertes & SLA)**, **Annexe X (Règles de décision)**, **Annexe Z (Modèle de coûts)**, puis **plan 90 jours** (§7).

---

## 2. Contexte & faits clés (interne)

- **3 dépôts**, 1 magasin/dépôt ; marchandises typiques : tuiles, matériaux en sacs. **Chargements typiques** : **25–30 t** (semi).  
- **Capacité interne** : enlèvements jusqu’à **10 t** ; au‑delà → **affrètement externe** (ex. Médiafret, parfois sous‑traité).  
- **Pratique cible** : faire livrer **chez le dépôt le plus proche** du fournisseur puis **redistribuer** via **navette interne** (2×/semaine) ; **coût interne nettement inférieur**.  
- **Urgences clients** : certains cas imposent l’**express**, **au‑dessus de l’optimisation**.  
*(Source : entretien opérationnel avec la coordinatrice, voir transcription interne.)* fileciteturn0file0

---

## 3. Diagnostic (problèmes observés)

1) **Double affrètement** dû à des arbitrages locaux non alignés (tonnage ≠ bon critère).  
2) **Alertes SI insuffisantes** (ARC/ACK, confirmation d’enlèvement) ⇒ retards non détectés.  
3) **Satisfaction client** peu mesurée lorsque tout se passe bien ⇒ valeur non visible.  
4) **Connaissance relationnelle** (contacts chez fournisseur/transporteur) non structurée dans le SI. fileciteturn0file0

---

## 4. Cas externes (références utilisables)

- **Leroy Merlin — Réau / “Easylog” (~40 M€ ; 27 AGV STILL)** : modernisation et automatisation (SCM). **+55 % e‑commerce 2021** (presse sectorielle). *Conversion de “baisse coûts 11–15 %” en **formule**.*  
  Sources :  
  - Supply Chain Magazine (NL 3628, 2022) — https://www.supplychainmagazine.fr/nl/2022/3628/leroy-merlin-dote-son-entrepot-automatise-de-reau-de-27-agv-still-706966.php  
  - Stratégies Logistique — https://strategieslogistique.com/Comment-Leroy-Merlin-adapte-sa%2C12454  
  - ADEO (Overview 2023) — https://www.adeo.com/en/
- **Kingfisher Group / Castorama** : **NPS suivi mensuellement** au niveau Groupe ; **Castorama** est une bannière Kingfisher.  
  Sources : https://www.kingfisher.com/investors/ ; https://www.kingfisher.com/brands/
- **Saint‑Gobain — Transport Control Tower** : **−13 % CO₂** (LATAM) et **>10 M$** d’économies/5 ans (ARC Advisory / Logistics Viewpoints, 2022).  
  Sources : https://logisticsviewpoints.com/2022/01/31/is-saint-gobain-serious-about-reducing-their-carbon-footprint/ ; https://www.saint-gobain.com/

> **Usage** : ces cas servent de **références** et de **plages de scénarios** ; **aucun chiffre Gedimat** ne doit être inféré sans baseline mesurée.

---

## 5. Recommandations détaillées

### 5.1 Règle d’affectation dépôt (proximité d’abord)
- Choisir **le dépôt le plus proche du fournisseur** (si écart >15 km) ; si ≤15 km, optimiser pour la **meilleure boucle navette**.  
- **Dérogations valides (3)** : (i) Urgence client documentée, (ii) Contrainte fournisseur (point unique), (iii) Anomalie de coût (devis aberrant).  
- **Journaliser** toute dérogation (`exception_reason`).  
*(Voir Annexe X — Règles de décision)*

### 5.2 Alertes & SLA (sans achat logiciel)
- Champs requis : `promised_delivery_date`, `supplier_ack_date`, `customer_urgency_flag`, `pickup_confirmed_timestamp`, `depot_assigned`, `exception_reason`.  
- **SLA** : ARC/ACK ≤48 h ; pickup confirmé **J‑1 16:00** ; livraison dans fenêtre convenue.  
- **Alertes** : (i) ARC/ACK manquant (48 h) ; (ii) risque retard (J‑1) ; (iii) pickup non confirmé (J‑1 16:00) ; (iv) urgence client ⇒ bypass consolidation.  
*(Voir Annexe Y — Alertes & SLA)*

### 5.3 Mesure de satisfaction (20 clients pilote)
- Courriel simple (5 questions FR), 2 vagues : après livraison, après incident.  
- Stocker le score par **commande** pour relier aux arbitrages logistiques.  

### 5.4 Outil de scoring dépôt (Excel)
- **Formule** : `Score = w1×Volume + w2×Distance + w3×Urgence`.  
- Valider sur **50 cas historiques** ; seuils proposés : Distance (km) normalisée ; Urgence binaire (1/0) ou 0/2.

---

## 6. Gouvernance & responsabilités
- **Propriétaire** : Responsable Planification Logistique (arbitrage final).  
- **Rituels** : comité hebdo exceptions (15 min), revue mensuelle des indicateurs.  
- **Dépôts** : appliquer “proximité d’abord”; escalader les litiges (pas de négociation locale).

---

## 7. Plan 90 jours (jalons)

- **Sem. 1–2** : Alertes & SLA (emails/règles), questionnaire satisfaction, formation courte.  
- **Sem. 3–4** : Scoring dépôt (Excel), test 10 cas, itérations.  
- **Sem. 5–8** : Généralisation règle proximité, revue exceptions, collecte baseline (30 jours).  
- **Sem. 9–12** : Synthèse pilote, calcul RSI (formule), décision généralisation.

*(Gantt réalisable via `pgfgantt` en LaTeX — voir spéc §QG7)*

---

## 8. Indicateurs & validation (pilote)

- **Service** : % commandes livrées à la date promise.  
- **Satisfaction** : score post‑livraison (échelle 0–10).  
- **Coût affrètement** : €/t vs baseline.  
- **Taux de consolidation** : part des enlèvements “dépôt le plus proche + navette”.  
- **RSI (formule)** : voir haut de document ; **aucun € Gedimat** sans factures/devis.

**Seuils de réussite (indicatifs)** : Service +4 pts, Satisfaction +10 pts, Consolidation +15 pts, RSI > 0 sur 90 j (selon scénario).

---

## 9. Sensibilité (scénarios)

| Scénario | Hypothèse réduction | Interprétation |
|---|---:|---|
| Conservateur | 8 % | cas prudent, résultats partiels |
| Base | 12 % | référence externe (non Gedimat) |
| Haut | 15 % | cible ambitieuse sous contrôle |
> Calcul : appliquer la formule RSI avec la **baseline mesurée** (30 jours de factures Médiafret) et **coûts navette** internes.

---

## 10. Conformité & confidentialité

- **Réglementaire** : vérifier heures de conduite/repos, charge utile, affrètement, sous‑traitance. Intégrer **Code des transports** & accords locaux ; pas de conseil juridique dans ce document.  
- **Confidentialité** : ne pas diffuser à des concurrents ; **aucun chiffre interne** nominatif ; annexes chiffrées = **formules** + champs **à renseigner**.

---

## Annexes (fournies)
- **Annexe X — Règles de décision (playbook)**  
- **Annexe Y — Alertes & SLA (procédure + pseudo‑SQL)**  
- **Annexe Z — Modèle de coûts (formules + données à collecter)**  
- **QG1‑QG7 — Rapports de contrôle qualité**

*Sources internes* : entretien opérationnel (transcription). fileciteturn0file0  
*Références externes* : voir §4 (liens publics).
