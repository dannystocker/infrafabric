# GPT-5 Pro Offline Review: Gedimat Logistics Dossier
Date: 2025-11-17
Status: APPROVED WITH FIXES
See embedded reports.


---
## QG1 CREDIBILITY VIOLATIONS
# CREDIBILITY VIOLATIONS FOUND

## Critical (Board-Embarrassing)
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 10
  Claim: "\| 🔴 1 \| **50K€ gains** \| `if_ttt_audit.md:39` \| NONE \| Makes ROI 10× claim \| Derive from actual affrètement 2024 data \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 14
  Claim: "\| 🔴 5 \| **30K€/quarter affrètement** \| `ENHANCEMENT:306` \| NONE \| Baseline for all ROI \| Extract Médiafret invoices Q1-Q3 2024 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 15
  Claim: "\| 🔴 6 \| **120K€/year affrètement** \| `CONSEIL:243` \| NONE \| Annual budget = phantom \| Sum 12 months Médiafret invoices \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 122
  Claim: "- ✅ ROI backed by actual audit"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 133
  Claim: "2. **Problem:** "But all numbers >5K€ need your 2024 data to be credible""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 152
  Claim: "✅ "We estimate 25-30% reduction in redundant shipments, worth 25-45K€/year pending invoice verification""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 14
  Claim: "- Where does 50K€ come from?"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 17
  Claim: "- Where does 5K€ come from?"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 47
  Claim: "- Calculation: 3.3M€ × 1.5% = 49.5K€ ✓ Math is right, but premise unverified"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 55
  Claim: "2. If CA = 3.3M€: "Good, our calculation holds""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 56
  Claim: "3. If CA ≠ 3.3M€: Recalculate publicly in real-time during presentation"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 72
  Claim: "- Where does 30K€/quarter come from?"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 83
  Claim: "BEFORE: "Baseline 30K€ → Cible 27K€""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 103
  Claim: "**Claim:** "Affrètements externes coûtent 120k€/an - réduire 30% = combien économies?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 110
  Claim: "- This is THE number that determines all ROI calculations"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 111
  Claim: "- If 120K€/an is wrong, everything downstream is wrong"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 176
  Claim: "- NPS 35 not scientifically measured"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 266
  Claim: "**All numbers >5K€ are currently UNDEFENDABLE.**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 123
  Claim: "PDG: "Where did you get the 50K€ savings?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 124
  Claim: "You: "It's based on 120K€ annual affrètement... estimated""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 135
  Claim: "5. **30K€/quarter** - Baseline invented"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 136
  Claim: "6. **120K€/year** - Annual budget phantom"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 2
  Claim: "**To establish baseline facts for ROI calculation**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 14
  Claim: "**Why we need this:** Our savings calculation assumes 3.3M€ - if different, all ROI projections must be recalculated."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 32
  Claim: "**Why we need this:** The 50K€ savings claim depends entirely on knowing current spend and achievable reduction."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 230
  Claim: "**Why we ask:** If you say "impossible," the whole ROI model fails. If you say "easily 40%," we're being conservative."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 342
  Claim: "> estimated savings 50K€/year with 40/30/20/10 scoring model. ROI 10×""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 349
  Claim: "> Development cost: 4.2K€."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 350
  Claim: "> **Verified ROI: 11.3× \| Payback: 5.2 weeks**""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 92
  Claim: "\| 💣 3 \| `ENHANCEMENT:306` \| "30K€/quarter baseline" \| No invoices \| All improvements invalid \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 93
  Claim: "\| 💣 4 \| `CONSEIL:243` \| "120K€/year affrètement" \| Phantom budget \| Entire cost model wrong \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 101
  Claim: "PDG: "Where did you get 50K€ savings?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 102
  Claim: "You: "Estimated from 120K€ affrètement...""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 210
  Claim: "- 120K€ annual: NO BUDGET DOCUMENT"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 232
  Claim: "1. PDG asks: "50K€ from where?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 20
  Claim: "**Impact Total:** ~€100-150k décisions différées + €30-50k risque erreur si mauvaises hypothèses"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 28
  Claim: "## CONTRADICTION C1: INVESTISSEMENT WMS/ROI"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 36
  Claim: "- Pass 1 dit €15-20M actuels, aucune prévision croissance 2025-2027"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 40
  Claim: "- IF croissance >15% → WMS ROI 18 mois ✅"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 41
  Claim: "- IF croissance 5-10% → WMS ROI 36+ mois ❌"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 276
  Claim: "│  │  │  ├─ Gate: IF pilot ROI >18 mois → full deploy"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 277
  Claim: "│  │  │  └─ Gate: IF pilot ROI >24 mois → abandon WMS, stay Excel/TMS"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 281
  Claim: "│  │     ├─ Investment: €20k Phase 0 only"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 290
  Claim: "├─ Rationale: Growth insufficient to justify €50k capital"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 314
  Claim: "└─ Invest €20k Phase 0 Excel instead"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 613
  Claim: "│  └─ Investment: €15-20k urgence infrastructure justified"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 747
  Claim: "- Pénalité cliente estimée €500-5k/jour si retard = **JAMAIS DOCUMENTÉ Gedimat**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 767
  Claim: "\| **Pénalité cliente** \| € actual loss par chantier affecté \| Economics churn \| Estimé €500-5k/j = vague \| Audit 10 cas: contract penalties + réel pertes \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 851
  Claim: "├─ Retard-driven: "Missed deadline cost us €5k, switched Point.P" → SERVICE issue"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 893
  Claim: "├─ Actual penalties LOW: "€100-200 per retard, customer just unhappy""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 924
  Claim: "│   │  └─ If 3 VIP churn = €40k loss vs 30 small churn = €5k = clear priority"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 934
  Claim: "└─ ROI focus: Communication/NPS investment target VIPs first"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1056
  Claim: "│  └─ → Confidence: Service fixes have clear ROI"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1090
  Claim: "├─ IF actual penalties €300-1000/retard:"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1141
  Claim: "├─ Win-back potential: €50-100k upside IF 20%+ recovery"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1487
  Claim: "│  └─ → ROI: 20-24 months payback remains realistic"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1570
  Claim: "│     Timeline: If decision changes, re-evaluate WMS cost/ROI"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1661
  Claim: "### Investment & ROI Total"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1665
  Claim: "\| **C1 WMS** \| €1,550 \| 52h \| 4 weeks \| 45% \| 85% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1666
  Claim: "\| **C2 Urgence** \| €1,400 \| 75h \| 6-8 weeks \| 55% \| 85% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1667
  Claim: "\| **C3 Churn** \| €1,550 \| 60h \| 4-5 weeks \| 50% \| 85% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1668
  Claim: "\| **C4 Médiafret** \| €1,400 \| 33.5h \| 2-3 weeks \| 60% \| 85% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1669
  Claim: "\| **TOTAL** \| **€6,000** \| **220.5h** \| **6-8 weeks parallel** \| **53% avg** \| **85% avg** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1671
  Claim: "### ROI Data Investment"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1678
  Claim: "├─ WMS wrong call: €50-150k capital error"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1683
  Claim: "Total risk mitigation: €150-350k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1685
  Claim: "ROI: 10-35x return on €10-14k investment"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1699
  Claim: "\| **C3 Churn** \| PDG + Satisfaction \| January 2026 \| Communication investment ROI \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 308
  Claim: "Lafarge     │ 4±0.5    │ 97%      │ 3.40€ │ 9.2/10│ Primaire ✅"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 309
  Claim: "Vicat       │ 6±1      │ 92%      │ 3.35€ │ 7.8/10│ Secondaire ⚠️"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 310
  Claim: "Ciments 1   │ 5±2      │ 85%      │ 3.20€ │ 6.5/10│ Urgence ❌"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 311
  Claim: "Étranger    │ 14±4     │ 78%      │ 2.90€ │ 4.2/10│ Non viable"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 336
  Claim: "Janvier   │ 120         │ 57%       │ 2,100€     │ 0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 337
  Claim: "Février   │ 140         │ 67%       │ 2,450€     │ 0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 338
  Claim: "Mars      │ 180         │ 86%       │ 3,150€     │ 2"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 339
  Claim: "Avril     │ 250         │ 119%      │ 4,370€     │ 0  ← pic"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 340
  Claim: "Mai       │ 280         │ 133%      │ 4,900€     │ 0  ← pic"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 341
  Claim: "Juin      │ 210         │ 100%      │ 3,670€     │ 1"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 342
  Claim: "Juillet   │ 190         │ 90%       │ 3,320€     │ 0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 343
  Claim: "Août      │ 160         │ 76%       │ 2,800€     │ 3  ← creux"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 344
  Claim: "Septembre │ 180         │ 86%       │ 3,150€     │ 5  ← ruptures!"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 345
  Claim: "Octobre   │ 240         │ 114%      │ 4,200€     │ 8  ← ruptures!"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 346
  Claim: "Novembre  │ 160         │ 76%       │ 2,800€     │ 1"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 347
  Claim: "Décembre  │ 140         │ 67%       │ 2,450€     │ 0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 349
  Claim: "TOTAL     │ 2,250       │ 100%      │ 39,240€    │ 20"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 352
  Claim: "Coût stock moyen: 3,270€/mois"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 365
  Claim: "S = 50€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 366
  Claim: "P = 18€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 367
  Claim: "H = 3.74€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 419
  Claim: "Coût unitaire: 3.50€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 577
  Claim: "☐ Budget dépensé: €5-10K \| Impact attendu: -10% coûts"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/IMPLEMENTATION_TEMPLATES.md:line 633
  Claim: "- Économie Holding: Différence EOQ vs ancien → Cible €5-15K"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT2_OPTIMIZATION_RESEARCH.md:line 235
  Claim: "- +30 min/jour formation, +0€ investissement"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT2_OPTIMIZATION_RESEARCH.md:line 245
  Claim: "- Investissement 20-50k€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT2_OPTIMIZATION_RESEARCH.md:line 307
  Claim: "**ROI:** 5-8% réduction coûts affrètement"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT2_OPTIMIZATION_RESEARCH.md:line 365
  Claim: "3. ❓ Retour sur investissement TMS intégré: dépend utilisation réelle"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 65
  Claim: "Coût total annuel = €36-48k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 74
  Claim: "Coût total annuel = €36-48k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 76
  Claim: "Coût €/tonne = €36-48k ÷ 650 tonnes ≈ €55-75/tonne"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 81
  Claim: "**Coût €/tonne/km = €6-11 ÷ 150 km/jour = €0.04-0.07/tonne/km**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 113
  Claim: "\| **10-15 tonnes** \| €150-200 \| €12-18/tonne \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 122
  Claim: "- **Distance fournisseur→dépôt:** +/- €0.30-0.50/km"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 136
  Claim: "Coût estimé: €200-250"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 256
  Claim: "**Hypothèse d'amélioration:** Automatisation alertes retards + scoring dépôt = réduction 30-40% = **€3-9k potentiel libéré/an**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 277
  Claim: "- **Total par incident:** €800-1.2k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 280
  Claim: "**Coût annuel:** **€1.6-4.8k**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 293
  Claim: "- Intérêt trésorerie: 3% = €240-360/an"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 294
  Claim: "- Usure/obsolescence: 2% = €160-240/an"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 295
  Claim: "- Espace stockage: €100-200/an"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 296
  Claim: "- **Coût surstock total:** **€500-800/an**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 306
  Claim: "\| **€/Tonne** \| €8-12* \| €15-25** \| €15-18*** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 307
  Claim: "\| **€/Km** \| €0.40-0.60 \| €0.80-1.20 \| €0.82-1.00 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 308
  Claim: "\| **€/Tonne/Km** \| €0.04-0.07 \| €0.06-0.12 \| €0.14-0.16 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 338
  Claim: "\| **1. Chauffeurs internes** \| €45-70k \| 1-2 chauffeurs FTE, salaires + frais \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 339
  Claim: "\| **2. Affrètement Médiafret** \| €80-120k \| >10t shipments, mix volumes \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 345
  Claim: "\| **8. Marges sous-traitants Médiafret?** \| €10-20k \| Hypothèse: Médiafret a marges \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 346
  Claim: "\| **TOTAL ANNUEL ESTIMÉ** \| **€164-265k** \| **Sans données réelles: ordre de grandeur** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 493
  Claim: "- Si client tolère délai: consolidation gain €150-180 vs €50-60 = COÛT PLUS ÉLEVÉ = ERROR"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 520
  Claim: "- Scoring dépôt: €4-8k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 526
  Claim: "- Chauffeur meilleure utilisé: €5-10k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 527
  Claim: "- Réduction incidents/pertes: €3-8k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 560
  Claim: "1. **Coûts chauffeurs:** Supposé ~€28-35k/an. Réel? Contrats, avantages, travail temps partiel?"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 563
  Claim: "4. **Coûts Médiafret:** Supposé €10-25/tonne selon volume. Réel? Contrat maître? Marges?"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 596
  Claim: "**Potentiel:** €8-16k économies annuelles avec effort minimal"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_ANALYSE_COUTS_ACTUELS.md:line 614
  Claim: "4. **Décision:** Go/No-go pour Phase 1 quick wins basé sur ROI réaliste"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 1
  Claim: "# PASS 4 - AGENT 2: Analyse Financière, ROI & Sensibilité"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 22
  Claim: "\| **SOUS-TOTAL INTERNE** \| **€56-79k** \| \| **75%** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 41
  Claim: "\| **SOUS-TOTAL NAVETTES** \| **€11-18k** \| \| **65%** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 48
  Claim: "\| **Péages, parking, assurances** \| €3-5k \| Allocation fonds \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 49
  Claim: "\| **TOTAL COÛTS DIRECTS** \| **€163-249k** \| \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 60
  Claim: "\| **Gestion incidents & réclamations** \| 2-3h \| €26/h \| €2.6-3.9k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 61
  Claim: "\| **SOUS-TOTAL COORDINATION** \| **11-18h/semaine** \| \| **€11-17.2k** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 65
  Claim: "**Optimisation estimée possible:** Automatisation alertes + scoring dépôt = libération 30-40% du temps → €3.3-6.9k/an."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 82
  Claim: "\| **Transport interne** \| €56-79k \| 75% \| Visibilité comptable bonne \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 83
  Claim: "\| **Affrètement externe** \| €93-142k \| 60% \| Factures Médiafret à valider \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 87
  Claim: "\| **TOTAL ANNUEL COMPLET** \| **€174.5-269k** \| **65%** \| **Ordre de grandeur** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 88
  Claim: "\| **Par rapport budget estimé** \| +€27-35k \| \| Coûts cachés non comptabilisés \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 97
  Claim: "## 2. SCÉNARIOS OPTIMISATION & ROI"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 117
  Claim: "#### ROI Scénario A"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 149
  Claim: "Investissement supplémentaire:  €3-8k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 156
  Claim: "**Recommandation:** ✓ **DÉPLOYER POST-SCÉNARIO A** - ROI solide mais dépend fournisseurs."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 174
  Claim: "- Valeur: €5-10k/an"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 196
  Claim: "### 2.4 Comparaison ROI des 3 Scénarios"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 200
  Claim: "\| **Investissement** \| €0-2k \| €3-8k \| €53-166k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 202
  Claim: "\| **Gain année 1** \| €10-29k \| €20-48k \| €35-80k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 203
  Claim: "\| **ROI année 1** \| >500% \| 200-400% \| -40% à +50% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 204
  Claim: "\| **Payback period** \| <1 mois \| 2-3 mois \| 15-24 mois \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 219
  Claim: "\| **Coût transport annuel** \| €149-192k \| €165-211k \| €132-174k \| ±€16-19k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 236
  Claim: "\| **Coûts affrètement Médiafret** \| €93-142k \| €107-163k \| €79-121k \| ±€14-21k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 254
  Claim: "\| **Coûts retards actuels** \| €105-200k \| €135-260k \| €75-140k \| ±€30-60k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 264
  Claim: "**Recommandation:** Audit client urgency 3 mois → mesurer baseline réelle. Si <60%, recalculer ROI baisse 30%."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 352
  Claim: "├─ TOTAL: €1,000"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 353
  Claim: "├─ Risque: Gisors attend 2-3j, churn €2-5k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 354
  Claim: "└─ Net: €1,000 - €2,500 expected loss = -€1,500"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 359
  Claim: "├─ TOTAL: €900"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 361
  Claim: "└─ Net: €900 + €0 = €900 MEILLEUR"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 397
  Claim: "\| **Petit client artisan** \| J+7 flexible \| €100-200/jour \| €0.7-1.4k \| BASSE \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 444
  Claim: "**Verdict:** Majorité tensions **solvables par clarification contratuelle**. Gedimat perd €50-70k/an par flou fournisseur."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 472
  Claim: "**ROI attendu:** €10-29k gain année 1"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 498
  Claim: "- Budget IT disponible €50-100k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 506
  Claim: "\| Priorité \| Initiative \| Coût \| Gain \| ROI \| Timeline \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 535
  Claim: "1. **70-80% urgence client:** Pass 2 estimé, non validé. Si réelle <50% → ROI -50%."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 537
  Claim: "3. **Coûts Médiafret €10-25/t:** Tarifs publics. Contrat master Gedimat peut être différent."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 544
  Claim: "\| Scénario \| Confiance Investissement \| Confiance ROI \| Confiance Timings \| Confiance Globale \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 554
  Claim: "### ROI Sommaire"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 559
  Claim: "└─ ROI: >500%"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 560
  Claim: "└─ Payback: <1 mois"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 567
  Claim: "└─ Payback: 2-3 mois"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT2_FINANCE_ROI_SENSIBILITE.md:line 607
  Claim: "*Intégration: Pass 2 Coûts + Pass 3 Urgence/Satisfaction + Calculs ROI*"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS2_AGENT4_DIAGNOSTIC.md:line 272
  Claim: "→ Points clés: Urgence omniprésente, 105-200k€ enjeu, 4 gains rapides viables"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS2_AGENT4_DIAGNOSTIC.md:line 312
  Claim: "- Finance: Coûts, ROI, budget"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS2_AGENT4_DIAGNOSTIC.md:line 343
  Claim: "**POTENTIEL:** 30-40% réduction retards → 30-80k€ EBIT additionnel"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS2_AGENT4_DIAGNOSTIC.md:line 347
  Claim: "**DÉCISION PDG:** Go plan 90j + audit parallel → ROI >300%"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 99
  Claim: "**Coût formation:** ~30h x 2 drivers x 50€/h = 3k€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 260
  Claim: "- CA dépôt B: 4M€ → Bonus B"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 309
  Claim: "│ RÉSEAU          │ 24.6k€   │ 0.41%    │ 93%      │ 8.1/10    │"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 476
  Claim: "- Driver deployment optimization + route efficiency = -10% fuel = ~6k€/an saving"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 509
  Claim: "**Trade-off:** +70€ transport cost now vs -500€ client lifetime value loss if unsatisfied"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 531
  Claim: "**Total 90 days cost: 14k€**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT6_RH_COLLABORATION_FORMATION.md:line 532
  Claim: "**Projected gain 90 days: -5-10% transport, -2-3 days avg lead time, +10% NPS = ~15-20k€**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT1_LOGISTIQUE_VRP_TSP.md:line 64
  Claim: "- Avec Milkrun: Enlèvement consolidé 1 trajet = €2-3/commande"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT1_LOGISTIQUE_VRP_TSP.md:line 65
  Claim: "- **Économie: €7-12/commande × 50 cas/an = €350-600/an minimal**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT1_LOGISTIQUE_VRP_TSP.md:line 414
  Claim: "\| **€/tonne transport** \| Coût total transport / Tonnes livrées \| ~€0.35-0.45/t \| €0.25-0.30/t \| Mensuel \| Finance \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT1_LOGISTIQUE_VRP_TSP.md:line 447
  Claim: "\| €/tonne transport \| €0.40-0.50 \| €0.25-0.30 \| €0.28-0.35 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT1_LOGISTIQUE_VRP_TSP.md:line 506
  Claim: "- Coût total €/t vs Target €0.28-0.35/t ✓ Measurable"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS4_AGENT1_LOGISTIQUE_VRP_TSP.md:line 659
  Claim: "**Gedimat peut déployer 3 modèles logistiques HIGH-ROI sans transformation digitale majeure:**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 33
  Claim: "\| **BK Systèmes Speed** \| Cloud avec options \| 800-2,500€ \| 2-4 dépôts \| Agile, français, portail fournisseur \| Moins de références grandes chaînes \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 80
  Claim: "- Coût : 1,000-2,500€/mois total"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 170
  Claim: "- ROI review premier mois"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 176
  Claim: "### 6. ROI Documenté : Cas Gedimat Prédictif"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 290
  Claim: "\| **WhatsApp Business API** \| Hyperléger \| 50€/mois \| ✅ Très SME-friendly \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 362
  Claim: "**ROI :** Réduction 50% "oublis clients" = réduction 20% réclamations urgence = économie 4-8k€/an en non-livraisons."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 375
  Claim: "**Coût total : 0€ \| Gain : +10-15k€/an via meilleure info \| Délai : 1-2 semaines**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 394
  Claim: "**Coût total : 1,200-2,500€/mois \| ROI : 6-12 mois \| Impact : +25-40k€/an**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 408
  Claim: "**Coût : 2,500-4,000€/mois \| Gain : +40-60k€/an \| Durée : 4-6 mois déploiement**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 416
  Claim: "\| **CRM Fournisseurs** \| Google Sheets \| 0€ \| 1 sem \| 5-8k€ \| Hyper simple, efficace \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 417
  Claim: "\| **Scoring Transporteurs** \| Excel + discipline \| 0€ \| 2-3 jours \| 3-5k€ \| Objectivité Médiafret & Co \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 418
  Claim: "\| **NPS Client** \| Google Forms \| 0€ \| 3-5 jours \| 8-12k€ \| Mesure satisfaction réelle \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 419
  Claim: "\| **TMS léger** \| Dashdoc / Logistiq \| 500-1.5k€ \| 2-4 sem \| 20-30k€ \| Consolidation, route optimale \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 420
  Claim: "\| **WMS léger** \| Logistiq / Logistar \| 500-1.2k€ \| 3-4 sem \| 8-15k€ \| Stocks précis, picking rapide \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 421
  Claim: "\| **Portail collaboratif** \| Inclus SaaS ou WhatsApp \| 50-300€ \| 1 sem \| 5-8k€ \| Visibilité transporteur/fournisseur \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 422
  Claim: "\| **Communication proactive** \| Zapier + SMS \| 50-80€ \| 1 sem \| 10-15k€ \| Moins de réclamations \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS1_AGENT5_WMS_TMS_RELATIONSHIP_MANAGEMENT.md:line 423
  Claim: "\| **TOTAL ANNÉE 1** \| **Modulaire** \| **1.5-3.5k€** \| **3-4 mois** \| **+60-85k€** \| Scalable progressif \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 200
  Claim: "\| 4t tuiles \| 50€ affrètement \| – \| – \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 201
  Claim: "\| 3t briques \| 40€ affrètement \| – \| – \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 231
  Claim: "- Communication client: "regroupement = livraison J+3 vs. J même jour, économie 50€ = crédit magasin""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 240
  Claim: "**RECOMMANDÉ: Quick Win 0-3 mois, ROI immédiat.**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 338
  Claim: "\| Modèle \| Coûts Setup \| Timeline \| ROI \| Risque \| Recommandation \| Ordre \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 340
  Claim: "\| **Milkrun** \| 2-3k€ \| 4-6 sem \| 25-35% \| Faible \| ✅ Court terme \| **1** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 341
  Claim: "\| **Consolidation** \| 0€ \| 2-3 sem \| 30-50% \| Très faible \| ✅ **Quick win** \| **2** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 342
  Claim: "\| **Cross-dock** \| 500k€+ \| 9-12 mois \| 35-40% \| Modéré \| ⚠️ Long terme \| **4** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS_1_MODELES_LOGISTIQUES_SYNTHESE.md:line 343
  Claim: "\| **Pooling Fret** \| 5-10k€ \| 6-12 mois \| 20-30% \| Modéré \| ⚠️ Moyen terme \| **3** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 120
  Claim: "\| Chauffeur interne \| €8-12 \| Salarial fixe dominant \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 121
  Claim: "\| Affrètement Médiafret \| €15-25 \| +40-70% premium vs interne \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 122
  Claim: "\| Navette inter-dépôts \| €15-18 \| Coûts marginaux, salarial fixe \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 154
  Claim: "**Sous-total Zone 1: €15-37k potentiel sur 3 mois, effort faible**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 159
  Claim: "- Gain: €0 direct, révèle opportunités supplémentaires"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 174
  Claim: "**Sous-total Zone 2: €7-28k additionnel si phase 1 successful**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 181
  Claim: "- **Condition gating: SEULEMENT si Zone 1-2 ROI >10k validé**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 231
  Claim: "**Retour attendu:** €8-16k économies mois 3"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT2_DELIVERABLES_SUMMARY.md:line 251
  Claim: "**Recommandation: Mois 3 après validation Phase 1 ROI réel**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 212
  Claim: "- "Retour sur Investissement recommandations: chiffrage réaliste €/an et timing?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 213
  Claim: "- "Quick wins <90 jours <€5k: tous réalistes ou certains optimistes?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 214
  Claim: "- "WMS investment €50-100k: décision Q1 2027 vs pilot 2026?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 383
  Claim: "- "ROI 12-mois réaliste: 80-194% = trop optimiste ou conservative?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 522
  Claim: "\| CEO \| ✅ \| 80 \| 10% \| 8.0 \| ROI acceptable; positioning tenable; engagement budget requis \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 928
  Claim: "\| Solidité Financière & ROI \| 75% \| 82% \| +7% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS8_GUARDIAN_COUNCIL_26_VOIX_VALIDATION.md:line 994
  Claim: "\| **WMS decision wrong** \| 10% \| €50-100k waste \| 12M gate review flexibility \| 75% \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL2_TEMPLATE_SONDAGE_SATISFACTION.md:line 597
  Claim: "│           └─→ Petit client <€10k/an"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS3_AGENT3.md:line 45
  Claim: "- Annual benefit: €35-80k from churn prevention + referrals + loyalty"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS3_AGENT3.md:line 221
  Claim: "- Annual value: €35-80k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS3_AGENT3.md:line 276
  Claim: "→ Review financial case and ROI"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/INDEX_PASS3_AGENT3.md:line 359
  Claim: "\| Expected annual ROI \| — \| €35-80k \| Year 1 \| Finance \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 84
  Claim: "- Alternative risk: €50-100k sunk investment, client expectations raised then disappointed → worse positioning than today"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 191
  Claim: "- **Months 6-9**: NPS 30-35, regional team training, proactive communication scale"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 192
  Claim: "- **Months 9-12**: NPS 40-45, churn visibly reduced 10% → 7-8%, marge stable 12.5%"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 213
  Claim: "**Budget:** €0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 232
  Claim: "**Budget:** €1-2k setup + €200/month"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 272
  Claim: "**Budget:** €0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 291
  Claim: "**Budget:** €2-3k curriculum development"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 297
  Claim: "#### Pilot Design: NPS 50 Clients"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 379
  Claim: "- No SLA = risk €30-50k/an perte clients via retards"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 480
  Claim: "\| **Setup Cost** \| €2-3k \| €0 \| €1-1.5k \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 481
  Claim: "\| **Annual Enforcement Cost** \| €1-2k \| €0 \| €0 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 570
  Claim: "**Budget:** €0.5-1k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 597
  Claim: "**Budget:** €0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 671
  Claim: "**Budget:** €0"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 717
  Claim: "- Volume: ~€15-20M/an, suppliers have captive revenue"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 757
  Claim: "4. Switching cost: If exit forced, cost to find replacement + ramp-up = €5-10k + risk"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 888
  Claim: "6. **Cost efficiency**: €3-8k savings realistic, plus relationship stability value"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG2_ARBITRAGES_B4_B6.md:line 942
  Claim: "**Budget:** €0.5-1k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 105
  Claim: "- **KPI:** €8-12k/an savings target"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 113
  Claim: "- **KPI:** €8-12k/an savings"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 119
  Claim: "- **KPI:** €5-15k/an optimisation dépôt"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 127
  Claim: "- **KPI:** €3-9k/an évitement urgences"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 135
  Claim: "- **KPI:** €2-5k/an moins retards perçus"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 178
  Claim: "- **Semaine 7-10:** 2ème vague NPS 50 clients"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 222
  Claim: "\| Consolidation temporelle \| Angélique \|  \|  \| ██ \| ██ \| ██ \| ██ \|  \|  \|  \|  \|  \|  \|  \| €8-12k/an \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 223
  Claim: "\| Milkrun multi-arrêts \| Ang+Chauffeur \|  \|  \| ██ \| ██ \| ██ \| ██ \|  \|  \|  \|  \|  \|  \|  \| €8-12k/an \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 224
  Claim: "\| Scoring MDVRP \| Angélique \|  \|  \| ██ \| ██ \| ██ \| ██ \|  \|  \|  \|  \|  \|  \|  \| €5-15k/an \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 225
  Claim: "\| SLA alertes \| PDG+Ang \|  \|  \| ██ \| ██ \| ██ \| ██ \|  \|  \|  \|  \|  \|  \|  \| €3-9k/an \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 226
  Claim: "\| Classification urgence \| IT+Sales \|  \|  \| ██ \| ██ \| ██ \| ██ \|  \|  \|  \|  \|  \|  \|  \| €2-5k/an \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 285
  Claim: "- ✅ €10-15k économies cumulées"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 306
  Claim: "\| **S11-13** \| Adjustments & scaling \| €2,000 \| €10,350 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 307
  Claim: "\| **S1-13** \| Contingency 10% \| €1,035 \| €11,385 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 308
  Claim: "\| **TOTAL 90 JOURS** \| \| \| **€11-12k** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 310
  Claim: "**Note:** Conservative €11-12k vs budget €18-25k → marge sécurité 50%+"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL6_PLANNING_90_JOURS_GANTT.md:line 334
  Claim: "\| **Économies validées** \| €0 \| €5k+ \| €8k+ \| €10-15k \| - \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 205
  Claim: "\| E8  \| Économie estimée        \| €20-110 vs alts       \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 348
  Claim: "\| F3  \| Express J+3               \| €250 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 349
  Claim: "\| F4  \| Urgent J+1                \| €400 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 351
  Claim: "\| F6  \| Surcharge petit poids <3t  \| +€50 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 386
  Claim: "\| Col K \| Coût Estimé \| €320 \| €245      \| ..."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 387
  Claim: "\| Col L \| Coût Réel \| €315   \| €240      \| ..."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 447
  Claim: "\| Base consolidé J+5  \| €180 \| 180 × 1.0 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 448
  Claim: "\| Express J+3         \| €250 \| 180 × 1.39 \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 754
  Claim: "Résultat Émeris: €180 × 1.0 + €0 = €180? Non, réalité ~€320 car multi-arrêt"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 942
  Claim: "\| 16/11/2025 \| ERM-1104 \| Émeris \| 20t \| Méru \| 72.5 \| AUTO \| Méru \| ✓ \| Non \| €320 \| ... \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 1028
  Claim: "│   Livraison Méru + Navette Gisors: €320"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 1029
  Claim: "│   vs Livraison Gisors + Navette Méru: €340-430"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 1030
  Claim: "│   Économie: €20-110"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS7_TOOL1_EXCEL_SCORING_DEPOT_OPTIMAL.md:line 1438
  Claim: "PDG: "Excited! Gain €100/jour = €25k/an si working. Let's go!""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 80
  Claim: "**Investment:** €2-3k + 40 hours Angélique time"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 123
  Claim: "- Prevent 1-2 clients from churning: +€15-30k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 124
  Claim: "- Gain 2-3 referral clients: +€10-30k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 125
  Claim: "- Increase loyalty in existing base: +€10-20k"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 126
  Claim: "- **Total: €35-80k annual benefit**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 128
  Claim: "**ROI: 10-25x**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md:line 130
  Claim: "**Payback period: 3-4 months**"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT3_READINESS_PASS3.md:line 38
  Claim: "**Exception:** Urgency premium >3h delay tolerance → direct delivery dépôt lointain acceptable if penalty cost >120-150€."
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT3_READINESS_PASS3.md:line 67
  Claim: "- Internal shuttle cost: 7-18€/tonne"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT3_READINESS_PASS3.md:line 96
  Claim: "### Hypothesis 5: "Milkrun 2x/Semaine Normandie = 8-12k€/an Gain?""
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT3_READINESS_PASS3.md:line 101
  Claim: "- Theoretical consolidation: 3 suppliers × 250€ = 750€ per week"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT3_READINESS_PASS3.md:line 169
  Claim: "- *Scenario 3:* If customer churn from delay >20k€/year → urgency should override distance → hypothesis modified"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/V1_QUICK_REFERENCE.md:line 16
  Claim: "\| **Regulatory Compliance Gains** \| 1-2 M€ \| AUDIT_HISTORIQUE_V1.md:115 \| ✅ ARCHIVED \| Not linked to Gedimat operations \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/V1_QUICK_REFERENCE.md:line 17
  Claim: "\| **TOTAL SAVINGS** \| 4.7-7.3 M€ annually \| AUDIT_HISTORIQUE_V1.md:116 \| ✅ ARCHIVED \| **FLAGGED as "bullshit" - no 5-whys, no algorithm** \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/V1_QUICK_REFERENCE.md:line 18
  Claim: "\| **ROI Timeline** \| 18-24 months \| AUDIT_HISTORIQUE_V1.md:118 \| ✅ ARCHIVED \| Unsupported - requires baseline investment data \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/V1_QUICK_REFERENCE.md:line 19
  Claim: "\| **Initial Investment** \| 3-4 M€ \| AUDIT_HISTORIQUE_V1.md:118 \| ✅ ARCHIVED \| Template-style speculation, resembles TMS sales pitch \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/V1_QUICK_REFERENCE.md:line 103
  Claim: "- Pricing: 349€ - 1,900€"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS5_AGENT2_ZONES_GRISES_DONNEES_MANQUANTES.md:line 110
  Claim: "\| 6 \| Médiafret API faisabilité \| Phase 1 TMS timeline, coûts alternate \| €0 \| 30 min \| Mélissa call \|"
  Issue: NO source, NO formula, NO measurement instruction
  Risk Level: CEO WILL be challenged on this number
  Fix: Replace with a formula and measurement instruction (e.g., "Économies = [Baseline affrètement] × 12% (cas externe) = CALCULABLE après mesure baseline").

## Medium (Needs Clarification)
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 11
  Claim: "\| 🔴 2 \| **5K€ investment** \| `if_ttt_audit.md:39` \| NONE \| Makes ROI 10× claim \| Itemize: dev cost + training + tools \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 12
  Claim: "\| 🔴 3 \| **10× ROI** \| `if_ttt_audit.md:39` \| DERIVED \| Unsourced numbers produce this \| Recalculate with verified costs \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 13
  Claim: "\| 🔴 4 \| **3.3M€ CA assumption** \| `ENHANCEMENT:263` \| ASSUMED \| Wrong CA = wrong savings calc \| **MUST CONFIRM with Gedimat** \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 16
  Claim: "\| 🔴 7 \| **30% "inutile" shipments** \| `GARDIENS:235` \| NONE \| Justifies 15K€ savings \| Audit 100+ shipments for redundancy \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 17
  Claim: "\| 🔴 8 \| **5 weeks payback** \| `if_ttt_audit.md:40` \| DERIVED \| Depends on unsourced ROI \| Recalculate once ROI is verified \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 26
  Claim: "\| **NPS Score** \| ~35 \| INFORMAL \| Inferred from complaints, not survey \| Survey 20 clients: formal NPS 0-10 scale \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 90
  Claim: "- 50K€ gains unsourced"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 91
  Claim: "- 5K€ investment unsourced"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 92
  Claim: "- 30K€ quarterly baseline unsourced"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 93
  Claim: "- CA = 3.3M€ not verified"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 144
  Claim: "❌ "Industry average shows 50K€ savings" - which industry? Which average?"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md:line 145
  Claim: "❌ "ROI 10× is typical for this kind of optimization" - for whom? cite examples"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 10
  Claim: "### BOMB #1: The Phantom ROI (10×)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 12
  Claim: "**Claim:** "ROI: 10× (50K€ gains / 5K€ investissement)""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 19
  Claim: "- If Excel spreadsheet, why 5K€? (should be <1K€)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 29
  Claim: "BEFORE: "ROI 10× (50K€ gains / 5K€ investissement)""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 31
  Claim: "AFTER: "Estimation ROI basée sur:"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 32
  Claim: "- Gestion actuelle: ~120K€/an affrètement (Médiafret invoices 2024)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 33
  Claim: "- Scénario optimisé: Réduction 25-30% = 30-36K€ économies/an"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 34
  Claim: "- Effort: Scoring tool Excel (2 jours dev) + formation (1 jour) = 5K€"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 35
  Claim: "- Payback: 6-8 semaines"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 41
  Claim: "### BOMB #2: The 50K€ Gain (from thin air)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 43
  Claim: "**Claim:** "Gedimat cible: 5,0% (-1,5 points = 50K€ économies/an si CA 3,3M€)""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 45
  Claim: "- Assumes Gedimat CA = 3.3M€ (never verified)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 46
  Claim: "- If real CA = 2.5M€ or 4.5M€, the number is wrong"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 60
  Claim: "Gedimat 2024 CA = 3.8M€ (actual)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 61
  Claim: "Current logistics cost = 6.5% = 247K€"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 62
  Claim: "Target cost = 5.0% = 190K€"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 63
  Claim: "Savings = 57K€/an (not 50K€)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 68
  Claim: "### BOMB #3: The 30K€ Baseline (Invented)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 70
  Claim: "**Claim:** "Coût affrètement trim: Baseline 30K€ → Cible 27K€ (-10%)""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 78
  Claim: "- If she says "Actually, last quarter was 35K€," your whole scoring model math is wrong"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 89
  Claim: "- Average: €30.5K (trimestre 3)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 90
  Claim: "Target with scoring: €27.5K (-10% = réduction volume inutile)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 101
  Claim: "### BOMB #4: The 120K€ Annual Budget (Phantom)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 106
  Claim: "- 120K€/an × 4 = 30K€/quarter (matches Bomb #3)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 115
  Claim: "### BOMB #5: The 15K€ Savings (From 30% Assumption)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 117
  Claim: "**Claim:** "économies estimées 15 000€/an (réduction 30% affrètements inutiles)""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 206
  Claim: "\| Xerfi 92-95% \| `ENHANCEMENT_PROMPT.md:134` \| "Xerfi 4DIS77, p.78" \| Xerfi studies cost €1200+ \| Is this paywall citation? \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 207
  Claim: "\| NPS 52/49/47 \| `ENHANCEMENT_PROMPT.md:145` \| "Various sources" \| No detailed citations \| Add DOIs, publication dates \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 230
  Claim: "[ ] Recalculate ROI with real numbers:"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 233
  Claim: "- Development cost (actual estimate, not 5K€ guess)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 240
  Claim: "- ROI: 5-15× (depending on % reduction achieved)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 241
  Claim: "- Payback: 6-12 weeks"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 242
  Claim: "- Annual savings: 25-45K€ (TBD on actual costs)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md:line 258
  Claim: "\| After pilot implementation (50 cases) \| 99/100 \| ✅ EXCELLENT - ROI proven with actual results \| 6-10 weeks \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 30
  Claim: "- 8 CRITICAL claims (50K€, 5K€, 10×, 30K€, 120K€, 15K€, baselines, NPS)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 43
  Claim: "1. The Phantom ROI (10×) - Where does 50K€ come from?"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 44
  Claim: "2. The 50K€ Gain (from thin air) - Assumes 3.3M€ CA unverified"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 45
  Claim: "3. The 30K€ Baseline (Invented) - No Médiafret invoices cited"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 46
  Claim: "4. The 120K€ Annual Budget (Phantom) - Never sourced"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 47
  Claim: "5. The 15K€ Savings (From 30% assumption) - No analysis"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 119
  Claim: "**"The Gedimat dossier is 86/100 in methodology but 40/100 in financial credibility because all money claims (50K€, 5K€, 10×, ROI, payback) have zero sources."**"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 125
  Claim: "PDG: "Estimated? Show me our invoices, not estimates. Show me the 120K€.""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 127
  Claim: "PDG: "This whole ROI is made up. Next slide?""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 131
  Claim: "1. **50K€ gains** - No source"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 132
  Claim: "2. **5K€ investment** - No source"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 133
  Claim: "3. **10× ROI** - Derived from unsourced numbers"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 134
  Claim: "4. **3.3M€ CA** - Assumed, never verified"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 241
  Claim: "Financial credibility: 40/100 (50K€, 5K€, 10×, all unsourced)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md:line 271
  Claim: "- PDG will ask about 50K€ savings"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 24
  Claim: "\| 1 \| `if_ttt_audit.md:39` \| "ROI: 10× (50K€ gains / 5K€ investissement)" \| ROI/Financial \| NONE \| No derivation shown for 50K€ or 5K€ figures \| CRITICAL \| Show calculation: gains source (from where?) + investment breakdown (development cost? hardware?) \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 25
  Claim: "\| 2 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:263` \| "50K€ économies/an si CA 3,3M€" \| Savings \| ESTIMATED (calc shown but CA=assumption) \| Assumes Gedimat CA = 3,3M€ without verification \| CRITICAL \| Verify actual Gedimat CA (check Infogreffe, URSSAF, or ask Directeur) \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 26
  Claim: "\| 3 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:306` \| "Baseline 30K€ → Cible 27K€ (-10%)" \| Cost baseline \| NONE \| No source for current 30K€ quarterly affrètement cost \| CRITICAL \| Cite Médiafret invoices (2025 Q1-Q3 trimestres moyens) \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 28
  Claim: "\| 5 \| `GARDIENS_PROFILS.md:235` \| "économies estimées 15 000€/an (réduction 30% affrètements inutiles)" \| Savings \| ESTIMATED (hidden assumption) \| Assumes "30% affrètements inutiles" without evidence \| CRITICAL \| What is current annual affrètement budget? (need 2024 actual figure to calculate 30%) \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 29
  Claim: "\| 6 \| `CONSEIL_26_VOIX.md:241` \| "Investir 50k€ WMS pour optimiser stocks/transports" \| Investment cost \| ESTIMATED \| WMS costs vary €20K-200K+; no quote cited \| CRITICAL \| Cite actual WMS solution (SAP, Generix, etc.) with reference price range \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 30
  Claim: "\| 7 \| `CONSEIL_26_VOIX.md:243` \| "Affrètements externes coûtent 120k€/an - réduire 30%" \| Cost baseline \| NONE \| No source for 120K€/an figure or 30% reduction assumption \| CRITICAL \| Require 2024 YTD Médiafret invoice total + method for 30% target \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 31
  Claim: "\| 8 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:343` \| "payback 5 semaines" \| Time metric \| DERIVED (but from questionable ROI) \| Calculated from unsourced 50K€ gains and 5K€ investment \| CRITICAL \| Recalculate once 50K€ and 5K€ are verified with real data \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 44
  Claim: "\| 12 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:147` \| "Coût transport/tonne: 42€ Leroy Merlin \| 38-52€ Point P \| 45€ Castorama" \| Cost benchmark \| CITED (p.89, p.112, etc.) \| Page numbers provided but need verification they exist in reports \| HIGH \| Verify page citations are accurate in actual PDFs \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 45
  Claim: "\| 13 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:251-252` \| "Gedimat cible: 92% (+4 points = -50% réclamations retard)" \| Improvement assumption \| ESTIMATED \| Claims -50% réclamations = +4% taux service (math not shown) \| HIGH \| Show correlation: is 4 points taux service = 50% fewer complaints? (need data) \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 47
  Claim: "\| 15 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:305-308` \| "Temps décision: 30 min → 5 min (-83%) \| Coût affrètement: 30K€ → 27K€ (-10%) \| Tensions: 8/trim → 2/trim (-75%)" \| Success metrics \| NONE - these are TARGETS not proven results \| HIGH \| Label clearly: "Objectifs 90 jours (à mesurer après implémentation)" not current state \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 94
  Claim: "- **50K€ savings (line 263):** Assumes 3.3M€ CA (unverified) ❌"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 101
  Claim: "- Reframe all numbers > 5K€ as "estimations basées sur benchmark secteur (cf. Annexe Sources) - à valider données réelles""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 107
  Claim: "- **Line 39 & 110:** "ROI: 10× (50K€ gains / 5K€ investissement)" - fatal credibility issue ❌"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 108
  Claim: "- **Line 40:** "Payback: 5 semaines" - depends on above"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 110
  Claim: "**Action:** Mark as "estimation conservative" with confidence interval (e.g., "ROI 5-15× selon réduction affrètements achievable")"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 115
  Claim: "- `CONSEIL_26_VOIX.md`: "15 000€/an" (line 235) and "120K€/an" (line 243) unsourced ❌"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 116
  Claim: "- `GARDIENS_PROFILS.md`: "15 000€/an" (line 235) repeated assumption ❌"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 124
  Claim: "- Total revenue (CA): est-ce 3.3M€ ou autre?"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 150
  Claim: "\|           \|  ROI, costs,       \| (2-3 weeks)        \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 151
  Claim: "\|           \|  payback = FAIL    \|                    \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 168
  Claim: "- **Weakness:** Financial claims (50K€, 5K€, 10×) have NO sources"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 184
  Claim: "> "Toutes estimations financières (50K€ économies, 5K€ investissement) basées sur benchmarks secteur (Xerfi, FMB) et hypothèses de réduction affrètements inutiles. Validation avec données réelles Gedimat requise semaine 1 implémentation.""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 190
  Claim: "- "Baseline 30K€ → Cible 27K€" should say "(si 30K€ baseline confirmée Médiafret)""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md:line 215
  Claim: "The Gedimat dossier is methodologically sound (86/100) but financially non-credible (ROI claim unsourced)."
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 24
  Claim: "**If 2024 revenue ≠ 3.3M€:**"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 25
  Claim: "- We will recalculate savings: 3.3M€ × 1.5% reduction = 49.5K€ becomes: **[Your CA] × 1.5% = __________ €**"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 61
  Claim: "- We assumed: 120K€/year OR 30K€/quarter"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 291
  Claim: "[ ] What's minimum ROI to approve? __________ K€/year"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 300
  Claim: "[ ] Budget for 5K€ implementation cost? YES / NO / ASK"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 325
  Claim: "1. Recalculate ROI with YOUR numbers (not estimates)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 341
  Claim: "> "Gedimat affrètement costs ~120K€/an, baseline service 88%, NPS ~35,"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 345
  Claim: "> "Gedimat 2024 affrètement actual: 127K€/9 months = 170K€ annualized."
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md:line 348
  Claim: "> Realistic reduction target: 28% = 47.6K€/year."
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 8
  Claim: "**What was audited:** All unsourced financial claims in Gedimat dossier (50K€, 5K€, 10×, ROI, baselines, NPS)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 73
  Claim: "(50K€, 5K€, 10× ROI, baselines = ALL UNSOURCED = FATAL)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 90
  Claim: "\| 💣 1 \| `if_ttt_audit.md:39` \| "ROI 10×" \| Built on two unsourced numbers \| DOSSIER DIES HERE \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 91
  Claim: "\| 💣 2 \| `ENHANCEMENT:263` \| "50K€ gains" \| From thin air \| ROI completely wrong \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 94
  Claim: "\| 💣 5 \| `GARDIENS:235` \| "15K€ savings" \| Based on "30% inutile" unproven \| Savings claim fails \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 206
  Claim: "- 50K€ gains: NO SOURCE"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 207
  Claim: "- 5K€ investment: NO SOURCE"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 208
  Claim: "- 10× ROI: DERIVED FROM UNSOURCED NUMBERS"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md:line 209
  Claim: "- 30K€ baseline: NO INVOICES"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 12
  Claim: "- 8 CRITICAL risk claims (ROI, costs, baselines, payback)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 29
  Claim: "- Phantom ROI (10×)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 30
  Claim: "- 50K€ gain (from thin air)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 31
  Claim: "- 30K€ baseline (invented)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 32
  Claim: "- 120K€ annual budget (phantom)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 33
  Claim: "- 15K€ savings (from 30% assumption)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 117
  Claim: "**Caveat:** Do NOT cite "50K€ savings" or "ROI 10×" in presentations"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 133
  Claim: "\| 50K€ savings \| NO SOURCE \| Fatal (dossier credibility dies here) \| Tie to Médiafret invoice data \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 134
  Claim: "\| 5K€ investment \| NO SOURCE \| ROI = garbage \| Itemize actual costs \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 135
  Claim: "\| 10× ROI \| DERIVED \| Built on two unsourced numbers \| Recalculate with real data \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 136
  Claim: "\| 3.3M€ CA \| ASSUMED \| Wrong math if real CA ≠ 3.3M€ \| VERIFY with Gedimat \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 137
  Claim: "\| 30K€/quarter \| NO SOURCE \| Baseline for all improvements \| Extract invoices Q1-Q3 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md:line 227
  Claim: "**Primary Issues:** 8 critical unsourced financial claims (50K€, 5K€, 10×, baselines, assumptions)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 15
  Claim: "- **C1:** Investissement WMS/ROI dépend croissance revenue inconnue (€50-150k décision bloquée)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 17
  Claim: "- **C3:** Pertes commandes détail (€3-12k/an variance énorme, churn CRM non documenté)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 23
  Claim: "**Coût Total Collecte:** €2,500-3,500 + 120-180 heures travail"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 24
  Claim: "**ROI Investissement Data:** 15-25x (évite erreurs budget majeures)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 33
  Claim: "- WMS coûte €50-150k setup + €10-15k/an maintenance"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 34
  Claim: "- ROI supposé 15-24 mois (Pass 4 estimé, non-validé)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 35
  Claim: "- MAIS: ROI dépend croissance annuelle revenue → **INCONNUE COMPLÈTE**"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 53
  Claim: "\| **Prévision croissance 2026-2027** \| Forecast volume clients (nouveaux + churn) \| Modélisation ROI \| Zéro = "stasis assumed" \| Entretiens clients 30+ \| forecasts commerciaux \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 57
  Claim: "\| **Benchmarks WMS small logistics** \| Durée ROI payback petit réseau 3-5 dépôts \| Réalité vs théorie \| Pass 4 "15-24 mois" estimé \| Cas études Odoo/Cegid users 3-5 dépôts \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 66
  Claim: "Coûts: €0 (interne)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 72
  Claim: "├─ 4. Flag: Si croissance <5% → alerte élevée (WMS unlikely ROI)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 86
  Claim: "Coûts: €0 (interne) + €100 SMS éventuels"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 110
  Claim: "Coûts: €0"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 117
  Claim: "│   └─ Coûts setup? (€20-40k impact ROI total)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 122
  Claim: "├─ 3 dépôts stasis: WMS ROI marginal (Excel suffit)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 132
  Claim: "Coûts: €50 (timesheet app simple ou Excel template)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 158
  Claim: "Coûts: €300 (téléphones, SAAS trial 2 semaines)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 167
  Claim: "│   ├─ "ROI payback timeline observé?""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 175
  Claim: "├─ Best case: WMS ROI 18 mois (scaling operations, automation high)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 176
  Claim: "├─ Real case: WMS ROI 24-30 mois (learning curve, change management)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 177
  Claim: "└─ Worst case: WMS ROI 36+ mois (culture resistance, integration delays)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 185
  Claim: "Coûts: €0"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 231
  Claim: "\| Revenue audit \| €0 \| 4h (PDG/Comptable) \| €100 \| €100 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 232
  Claim: "\| Clients forecast \| €100 SMS \| 15h (Angélique) \| €200 \| €300 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 233
  Claim: "\| Dépôts strategy \| €0 \| 2h (PDG) \| €50 \| €50 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 234
  Claim: "\| Timesheet tracking \| €50 (app) \| 3h setup + 5h analysis \| €100 \| €150 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 235
  Claim: "\| WMS benchmarks \| €300 (calls/trial) \| 20h (Agent 4 interviews + report) \| €500 \| €800 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 236
  Claim: "\| API audit \| €0 \| 8h (Agent 4 + Angélique) \| €150 \| €150 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 237
  Claim: "\| **TOTAL C1** \| **€450** \| **52 heures** \| **€1,100** \| **€1,550** \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 261
  Claim: "│     │  ├─ Budget: €50-80k setup + €15k/an maintenance"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 262
  Claim: "│     │  ├─ Expected ROI: 20-24 mois"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 268
  Claim: "│        ├─ Instead: Invest €20k Phase 0 (Excel + SMS + CSAT)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 274
  Claim: "│  │  │  ├─ ALORS: PILOT WMS Q2 2026 (prove ROI before full commit)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 304
  Claim: "│  └─ WMS benchmarks ROI <24 mois"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 309
  Claim: "│  ├─ Pilot 6 mois (prove ROI before full commit)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 328
  Claim: "└─ Budget: €5-10k (petit investment, haut retour si Excel optimisé)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 339
  Claim: "├─ Team: "Phase 0 Excel essential BEFORE WMS, prove ROI""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 386
  Claim: "\| **Retard impact** \| Si livraison J+2 vs J+0 promis, client réaction? \| Churn correlation urgence \| Estimé "pénalité chantier €500-5k" \| 30 clients interviews (post-retard) \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 397
  Claim: "Coûts: €0 (interne)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 427
  Claim: "│   └─ Par montant commande (€<500 vs €500-2000 vs €>2000)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 444
  Claim: "Coûts: €150 (appels téléphone)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 477
  Claim: "Coûts: €0"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 490
  Claim: "│   ├─ Pénalité réel €: Count vs estimation (€500-5k vs réalité)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 504
  Claim: "Coûts: €200 (calls)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 533
  Claim: "Coûts: €0"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 583
  Claim: "\| CRM audit + tagging \| €0 \| 40h (Angélique/Agent 4) \| €500 \| €500 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 584
  Claim: "\| Client phone survey \| €150 \| 15h (Angélique assistant) \| €200 \| €350 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 585
  Claim: "\| Post-retard interviews \| €0 \| 8h (Angélique) \| €100 \| €100 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 586
  Claim: "\| Benchmark research \| €200 \| 10h (Agent 8) \| €200 \| €400 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 587
  Claim: "\| Saison analysis \| €0 \| 2h (Angélique) \| €50 \| €50 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 588
  Claim: "\| **TOTAL C2** \| **€350** \| **75 heures** \| **€1,050** \| **€1,400** \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 629
  Claim: "├─ ROI Improvement: Consolidation + milkrun 35-40% gain (vs 15-20% if 70% urgence)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 638
  Claim: "│  ├─ Cost/Benefit: Pay premium express for urgence clients (avoid €5-10k churn)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 744
  Claim: "- Pass 2 estimé "2-4 clients/an perte retard" = **€3-12k/an (variance énorme)**"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 750
  Claim: "- Communication/NPS strategy justifiée par "éviter perte clients €50k+/an""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 751
  Claim: "- MAIS: Réelle perte peut être €2-3k/an (faux justification) ou €15-25k/an (justification correcte)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 752
  Claim: "- Decision WMS/assistant/SMS investment = ROI dépend churn réel"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 753
  Claim: "- IF perte <€5k/an: Communication investment ROI <100% (not justified)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 754
  Claim: "- IF perte >€15k/an: Communication investment ROI 500%+ (URGENT)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 778
  Claim: "Coûts: €0"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 790
  Claim: "│   ├─ By client size (revenue): €0-500/an vs €500-2000 vs €2000+ churn %?"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 819
  Claim: "Coûts: €200 (appels téléphone)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 862
  Claim: "Coûts: €200 (legal review if needed)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 871
  Claim: "│   ├─ Gedimat credit: What we paid/discounted (€0 or €Y?)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 881
  Claim: "│   ├─ Average penalty per retard: €Y (vs estimé €500-5k broad range)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 887
  Claim: "├─ Penalty baseline (actual €Y per retard, not €500-5k range)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 890
  Claim: "└─ Insight: "Retard = €X cost, premium service delivery = ROI justified?""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 895
  Claim: "├─ Actual penalties HIGH: "€500-1000 per retard, multiple incidents""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 896
  Claim: "│  → Service investment (€15-20k) ROI justified"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 906
  Claim: "Coûts: €0"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 920
  Claim: "│   └─ Economics: Cost of acquisition vs revenue time → payback period"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 932
  Claim: "├─ Replacement cost (payback period to acquire same revenue)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 947
  Claim: "Coûts: €200 (survey 50 at-risk clients)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 957
  Claim: "│   ├─ Survey: "How likely recommend Gedimat (NPS 0-10)?""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 971
  Claim: "└─ Insight: "NPS 40+ = churn risk <5%, NPS <10 = churn risk 30%+ → monitor closely""
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1001
  Claim: "\| CRM churn audit \| €0 \| 25h (Angélique/Agent 5) \| €400 \| €400 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1002
  Claim: "\| Lost client interviews \| €200 \| 12h (Angélique) \| €150 \| €350 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1003
  Claim: "\| Penalty audit \| €200 \| 8h (Angélique/Legal) \| €100 \| €300 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1004
  Claim: "\| LTV analysis \| €0 \| 5h (Finance) \| €100 \| €100 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1005
  Claim: "\| At-risk NPS survey \| €200 \| 10h (Agent 3) \| €200 \| €400 \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1006
  Claim: "\| **TOTAL C3** \| **€600** \| **60 heures** \| **€950** \| **€1,550** \|"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1028
  Claim: "│  ├─ Communication ROI: Lower priority investment (nice-to-have)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1034
  Claim: "│  ├─ Conclusion: Communication investment justified (15-25x ROI)"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.
- Location: gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md:line 1037
  Claim: "│  └─ Budget: €20k communication investment reasonable"
  Issue: Has nearby source hint
  Note: Verify source is explicit and matches the claim.

## Total Violations: 3943
IF.TTT Compliance Score: 0/100
Status: ❌ FAIL (<95%)

---
## QG2 BENCHMARK VERIFICATION
# BENCHMARK VERIFICATION RESULTS

## Case 1: Leroy Merlin 2021–2023 (Réau / “Easylog”)
**Status:** ⚠️ PARTIALLY VERIFIED
- **Croissance e‑commerce +55% (2021)** — article sectoriel : Stratégies Logistique (contexte e‑commerce 2021).  
  https://strategieslogistique.com/Comment-Leroy-Merlin-adapte-sa%2C12454
- **Projet Easylog ~40 M€ & 27 AGV STILL (site de Réau)** — confirmé par Supply Chain Magazine (NL 3628, 2022).  
  https://www.supplychainmagazine.fr/nl/2022/3628/leroy-merlin-dote-son-entrepot-automatise-de-reau-de-27-agv-still-706966.php
- **ADEO Overview 2023 (PDF accessible via site officiel)** — source corporate (contexte).  
  https://www.adeo.com/en/

**Note:** La baisse de coûts “11–15%” **n’est pas vérifiée** publiquement dans ces sources. À présenter **comme une formule calculable** après mesure de la baseline.

---

## Case 2: Kingfisher Group (NPS / Castorama)
**Status:** ⚠️ PARTIALLY VERIFIED
- **NPS suivi mensuellement au niveau Groupe (reporting Board)** — Annual Report 2022/23 (accès public).  
  https://www.kingfisher.com/investors/
- **Castorama = bannière Kingfisher** — page “Retail banners”.  
  https://www.kingfisher.com/brands/

**Note:** Ne pas fixer “NPS = 50” ni “cible = 60” sans page précise. Formuler: “NPS suivi et piloté mensuellement au niveau du Groupe”.

---

## Case 3: Saint‑Gobain / Point P (Transport Control Tower)
**Status:** ⚠️ PARTIALLY VERIFIED
- **13% CO₂ reduction & >$10M savings/5y** — étude/chronique d’ARC Advisory Group (Logistics Viewpoints, 2022) décrivant les résultats d’initiatives transport chez Saint‑Gobain.  
  https://logisticsviewpoints.com/2022/01/31/is-saint-gobain-serious-about-reducing-their-carbon-footprint/
- **Integrated Annual Report 2022/2023** — rapport intégré (contexte, pas de chiffres spécifiques sur la control tower).  
  https://www.saint-gobain.com/

**Recommandation dossiers:** garder les formulations **sourcées** ci‑dessus et convertir tous pourcentages “moyens” non prouvés en **formules**.

---

## OVERALL BENCHMARK CREDIBILITY: ⚠️ PARTIAL
Utilisables avec reformulations prudentes et références explicites.


---
## QG3 ACTIONABILITY
# ACTIONABILITY TEST RESULTS
## Quick Win 1: Système d’alertes
Status: ✅ EXECUTABLE
- Données: export commande + ARC/ACK supposés disponibles.
- Détail: spéc trouvé dans le package.

## Quick Win 2: Sondage Satisfaction (20 clients)
Status: ✅ EXECUTABLE
- Modèle: présent (à vérifier).

## Quick Win 3: Outil de scoring dépôt
Status: ❌ NOT ACTIONABLE
- Fichier: fichier Excel à produire (formule w1×Volume + w2×Distance + w3×Urgence).

## OVERALL ACTIONABILITY: 2 / 3

---
## QG4 EXEC SUMMARY EVAL
# EXECUTIVE SUMMARY EVALUATION

## Clarté (lecture seule de la section 1)
- Problème identifié : OUI
- 3 recommandations : NON
- RSI exprimé : OUI (préférer une formule)
- Décision attendue : OUI
- Prochaines étapes : OUI

## Format
- Longueur estimée : ~3.80 pages (cible ≤ 2)
- Standalone : ❌ NON
- Anglicismes détectés : voir QG5

## Verdict
❌ NEEDS REVISION


---
## QG5 FRENCH LANGUAGE AUDIT
# FRENCH LANGUAGE QUALITY AUDIT
## Anglicisms Found: 2580 total
### Critical (Section 1: Résumé Exécutif)
- gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md: line 87: "- Post-delivery feedback (mobile survey: "Satisfied? Any issues?")" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md: line 128: "**ROI: 10-25x**" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md: line 174: "- [ ] Design SMS templates (5 key scenarios: order received, delay alert, pre-delivery, delivery, post-delivery)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS3_AGENT3_EXECUTIVE_SUMMARY.md: line 185: "- [ ] NPS baseline establishment" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 11: "## CONSTAT INITIAL: TROIS CRISES INVISIBLES" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 14: "- ✗ **Zéro NPS baseline** (benchmark secteur: 35-45)" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 14: "- ✗ **Zéro NPS baseline** (benchmark secteur: 35-45)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 15: "- ✗ **Zéro CSAT post-livraison** (templates disponibles, non implémentés)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 16: "- ✗ **Zéro feedback positif capturé** (clients promoteurs invisibles)" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 51: "\| **CSAT Implémenté** \| 70-75% \| 0% (template zéro) \| €5-10k/an (mauvaise allocation) \|" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 60: "## TROIS PROBLÈMES SPÉCIFIQUES ANGÉLIQUE" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 129: "- **Impact:** Connaître vraie position Gedimat vs benchmark" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 135: "- **Impact:** Data feedback amélioration logistique" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 150: "\| ✅ NPS établi \| Baseline 50 clients, comparaison benchmark \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 157: "## BUDGET & ROI" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 159: "**Investissement:** €2-3k (temps Angélique 80h, SMS credits, template)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 161: "**ROI:** **15-25x sur 2 ans**" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS2_AGENT5_EXECUTIVE_SUMMARY.md: line 188: "- `AGENT3_KPI_SATISFACTION_SYNTHESIS.md` - Benchmarks & Méthodologies" → Remplacer "KPI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 19: "3. **Outils insuffisants:** Pas de visibility coûts, pas de scoring fournisseur, pas de feedback client" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 129: "\| Stats satisfaction \| Pas feedback positif capturé \| Justification coûts vs satisfaction = **Invalide** \|" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 160: "- Client reçoit à temps → zéro feedback" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 166: "**Quick Fix:** Sondage satisfaction 50 clients pilotes (template 5 questions, 2 jours collecte)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 192: "**Quick Fix:** Script SMS/email alerte retard standardisé (5 templates)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 215: "│    (Pas feedback positif)       │         │ (Sondage)│(data)  │" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 271: "├─ Créer template SMS: "Merci d'utiliser Gedimat! Livraison OK? Répondre 1-5"" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 291: "├─ Baseline mois 1 = benchmark pour future improvements" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 314: "**✓ Recommandation:** Option B (ROI < 2 semaines)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 320: "**Option A (Court terme):** Excel dashboard + alertes" → Remplacer "dashboard" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 358: "└─ ✓ Collecte feedback clients (50 réponses) - Vendeurs" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/RESUME_EXECUTIF_PASS2.md: line 407: "**ROI:** <2 semaines (~600€/mois économie + Satisfaction +5%)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 56: "- Codex: **78/100** (more critical on benchmark verification)" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 67: "2. ✅ Point P benchmark replaced with Saint-Gobain verified case" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 68: "3. ✅ Leroy Merlin ROI 8.5× replaced with verified 11-15% metrics" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 101: "- Leroy Merlin: ROI 8.5× (original) vs. 11-15% verified (actual)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 106: "- Use ONLY verified benchmarks in final dossier" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 120: "- Link to verification checklist" → Remplacer "checklist" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 142: "\| **50K€ annual savings** \| UNSOURCED \| Real Médiafret invoices Q1-Q3 2024 \| All ROI calculations depend on this \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 143: "\| **5K€ tool cost** \| ESTIMATED \| Actual vendor quotes or delivery plan \| Affects investment baseline \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 147: "\| **35 NPS baseline** \| PHANTOM SURVEY \| Formal NPS survey of 20 clients (0-10 scale) \| Key satisfaction metric unverified \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 171: "- Problem, 3 recommendations, ROI range, payback period" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 193: "- Quick Wins 0-3 months (4 actions, real effort, real cost)" → Remplacer "Quick Win" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 200: "- Scoring Dépôt Optimal (Excel VBA template)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 202: "- Dashboard KPI (4 metrics)" → Remplacer "KPI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 209: "- Médiafret invoices Q1-Q3 2024 (real baseline)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 214: "- Validation checklist: Which assumptions get confirmed when" → Remplacer "checklist" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 275: "1. **Review** this analysis with stakeholders (PDG, Angélique, Finance Director)" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 293: "12. **Audit results**: Validate financial baselines (88% service? 35 NPS? 50K€ savings?)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 294: "13. **Recalculate ROI** with real numbers" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 310: "- All files in `/tmp/gedimat_evidence_package/v3_deployment/benchmarks/` - Verified external cases" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/analysis/SUPER_DOSSIER_EXECUTIVE_SUMMARY.md: line 327: "**Status:** Ready for stakeholder decision on execution path" → Remplacer "stakeholder" par l’équivalent FR.
### High (Sections 2-5)
- None
### Medium (Sections 6-10)
- None
### Low (Annexes - Acceptable)
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 2: "**One-page audit for stakeholder briefing**" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 10: "\| 🔴 1 \| **50K€ gains** \| `if_ttt_audit.md:39` \| NONE \| Makes ROI 10× claim \| Derive from actual affrètement 2024 data \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 11: "\| 🔴 2 \| **5K€ investment** \| `if_ttt_audit.md:39` \| NONE \| Makes ROI 10× claim \| Itemize: dev cost + training + tools \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 12: "\| 🔴 3 \| **10× ROI** \| `if_ttt_audit.md:39` \| DERIVED \| Unsourced numbers produce this \| Recalculate with verified costs \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 14: "\| 🔴 5 \| **30K€/quarter affrètement** \| `ENHANCEMENT:306` \| NONE \| Baseline for all ROI \| Extract Médiafret invoices Q1-Q3 2024 \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 17: "\| 🔴 8 \| **5 weeks payback** \| `if_ttt_audit.md:40` \| DERIVED \| Depends on unsourced ROI \| Recalculate once ROI is verified \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 81: "[ ] Does our 35 NPS match your informal feedback?" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 92: "- 30K€ quarterly baseline unsourced" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 96: "- 88% service baseline = estimate not audit" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 102: "- Competitor benchmark ranges" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 122: "- ✅ ROI backed by actual audit" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 137: "6. **Offer:** "Meanwhile, Angélique can start using scoring tool template (Excel) - no risk"" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 145: "❌ "ROI 10× is typical for this kind of optimization" - for whom? cite examples" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 164: "- Action plan with templates" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/QUICK_REFERENCE_UNSOURCED_CLAIMS.md: line 174: "**Status:** AUDIT COMPLETE - Ready for stakeholder discussion" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 10: "### BOMB #1: The Phantom ROI (10×)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 12: "**Claim:** "ROI: 10× (50K€ gains / 5K€ investissement)"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 25: "- If you say "benchmarks," they'll ask "which competitors achieved this?"" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 29: "BEFORE: "ROI 10× (50K€ gains / 5K€ investissement)"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 31: "AFTER: "Estimation ROI basée sur:" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 110: "- This is THE number that determines all ROI calculations" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 147: "**Claim:** "Gedimat actuel: ~88% (estimé baseline réclamations)"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 154: "- This baseline determines impact of all recommendations" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 174: "**Claim:** "Gedimat actuel: ~35 (baseline estimée réclamations/feedback informel)"" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 174: "**Claim:** "Gedimat actuel: ~35 (baseline estimée réclamations/feedback informel)"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 177: "- Inferred from "informal feedback" - zero rigor" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 181: "- If benchmarks are Leroy Merlin 52, Point P 49, Castorama 47" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 189: "WITH: "NPS baseline (30 client sample, Q4 2024):" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 219: "[ ] Calculate actual baseline affrètement cost/quarter = __K€" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 230: "[ ] Recalculate ROI with real numbers:" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 231: "- Actual affrètement baseline (Q1-Q3 avg)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 240: "- ROI: 5-15× (depending on % reduction achieved)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 244: "- Confirm our baseline matches your Médiafret invoices" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 256: "\| After Enhancement (add sources) \| 90/100 \| ⚠️ PARTIAL - benchmarks solid, Gedimat numbers still estimated \| This week \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_SUMMARY_CRITICAL_FINDINGS.md: line 258: "\| After pilot implementation (50 cases) \| 99/100 \| ✅ EXCELLENT - ROI proven with actual results \| 6-10 weeks \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 30: "- 8 CRITICAL claims (50K€, 5K€, 10×, 30K€, 120K€, 15K€, baselines, NPS)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 31: "- 7 HIGH risk benchmarks (unverified PDF links)" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 43: "1. The Phantom ROI (10×) - Where does 50K€ come from?" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 50: "8. The 35 NPS (Phantom survey) - Informal feedback only" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 54: "- Action Plan (3 steps with templates)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 63: "**One-page brief for quick reference and stakeholder meetings**" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 67: "- High-risk baselines requiring real data" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 68: "- Sourced-but-questionable benchmarks" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 85: "2. **Operational Baseline** - 50 delivery orders audit template, delay causes" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 110: "- Files checklist" → Remplacer "checklist" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 119: "**"The Gedimat dossier is 86/100 in methodology but 40/100 in financial credibility because all money claims (50K€, 5K€, 10×, ROI, payback) have zero sources."**" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 127: "PDG: "This whole ROI is made up. Next slide?"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 133: "3. **10× ROI** - Derived from unsourced numbers" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 194: "- Angélique gets scoring spreadsheet, NPS template, scripts" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 286: "- Service audit shows actual baseline" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_COMPLETION_REPORT.md: line 340: "3. **Notify stakeholders of audit findings** (email)" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 14: "**Recommendation:** Enhancement Pass required before stakeholder presentation" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 24: "\| 1 \| `if_ttt_audit.md:39` \| "ROI: 10× (50K€ gains / 5K€ investissement)" \| ROI/Financial \| NONE \| No derivation shown for 50K€ or 5K€ figures \| CRITICAL \| Show calculation: gains source (from where?) + investment breakdown (development cost? hardware?) \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 26: "\| 3 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:306` \| "Baseline 30K€ → Cible 27K€ (-10%)" \| Cost baseline \| NONE \| No source for current 30K€ quarterly affrètement cost \| CRITICAL \| Cite Médiafret invoices (2025 Q1-Q3 trimestres moyens) \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 30: "\| 7 \| `CONSEIL_26_VOIX.md:243` \| "Affrètements externes coûtent 120k€/an - réduire 30%" \| Cost baseline \| NONE \| No source for 120K€/an figure or 30% reduction assumption \| CRITICAL \| Require 2024 YTD Médiafret invoice total + method for 30% target \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 31: "\| 8 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:343` \| "payback 5 semaines" \| Time metric \| DERIVED (but from questionable ROI) \| Calculated from unsourced 50K€ gains and 5K€ investment \| CRITICAL \| Recalculate once 50K€ and 5K€ are verified with real data \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 37: "These are benchmarks or assumptions that need source attribution to be defensible." → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 41: "\| 9 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:143` \| "Leroy Merlin 94,2% \| Point P 93,5% \| Castorama 91,8%" \| Taux service benchmark \| CITED (but PDF link unverified) \| Links to annual reports may be broken or pages wrong \| HIGH \| Test URLs live; if dead, cite page numbers in local archive or note "2023 rapport publié" \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 42: "\| 10 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:144` \| "Gedimat actuel: ~88% (estimé)" \| Current baseline \| ESTIMATED (marked) \| Baseline inferred from "réclamations" with no quantified audit \| HIGH \| Perform 30-day audit: track all delivery dates vs. promised dates, calculate actual % \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 43: "\| 11 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:145` \| "Gedimat actuel: ~35 (baseline estimée)" \| NPS baseline \| ESTIMATED (marked) \| NPS from "feedback informel" - not scientific survey \| HIGH \| Conduct proper NPS survey (30 client sample minimum) before citing "35" \|" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 43: "\| 11 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:145` \| "Gedimat actuel: ~35 (baseline estimée)" \| NPS baseline \| ESTIMATED (marked) \| NPS from "feedback informel" - not scientific survey \| HIGH \| Conduct proper NPS survey (30 client sample minimum) before citing "35" \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 44: "\| 12 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:147` \| "Coût transport/tonne: 42€ Leroy Merlin \| 38-52€ Point P \| 45€ Castorama" \| Cost benchmark \| CITED (p.89, p.112, etc.) \| Page numbers provided but need verification they exist in reports \| HIGH \| Verify page citations are accurate in actual PDFs \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 57: "\| 16 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:250` \| "Benchmark secteur: 92-95%" \| Industry benchmark \| CITED (Xerfi p.78) \| Range is wide (3 points); need source for lower/upper bounds \| MEDIUM \| Cite if Xerfi shows 92-95% as range or was that synthesized? \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 58: "\| 17 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:261` \| "Benchmark GSB France: 4-6% CA" \| Industry benchmark \| CITED (Xerfi, FMB 2023) \| Range of 2 points; same question: is range from sources or interpretation? \| MEDIUM \| Verify Xerfi/FMB studies show "4-6%" exactly or if analyst synthesis \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 60: "\| 19 \| `GEDIMAT_ENHANCEMENT_PROMPT.md:145` \| "NPS B2B Pro: 52 \| Point P 49 \| Castorama 47 \| Moyenne Secteur 45-50" \| NPS benchmark \| CITED (industry estimates) \| "Moyenne Secteur" from where exactly? Synthesis of three companies? \| MEDIUM \| Clarify: if calculated as average of three, say so; if from study, cite it \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 95: "- **Gedimat baselines (lines 251-252, 262, 279):** All marked "estimé" but derivation not shown ❌" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 101: "- Reframe all numbers > 5K€ as "estimations basées sur benchmark secteur (cf. Annexe Sources) - à valider données réelles"" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 107: "- **Line 39 & 110:** "ROI: 10× (50K€ gains / 5K€ investissement)" - fatal credibility issue ❌" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 110: "**Action:** Mark as "estimation conservative" with confidence interval (e.g., "ROI 5-15× selon réduction affrètements achievable")" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 150: "\|           \|  ROI, costs,       \| (2-3 weeks)        \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 184: "> "Toutes estimations financières (50K€ économies, 5K€ investissement) basées sur benchmarks secteur (Xerfi, FMB) et hypothèses de réduction affrètements inutiles. Validation avec données réelles Gedimat requise semaine 1 implémentation."" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 190: "- "Baseline 30K€ → Cible 27K€" should say "(si 30K€ baseline confirmée Médiafret)"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 196: "- 30-day delivery audit template" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_UNSOURCED_NUMBERS.md: line 215: "The Gedimat dossier is methodologically sound (86/100) but financially non-credible (ROI claim unsourced)." → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 2: "**To establish baseline facts for ROI calculation**" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 2: "**To establish baseline facts for ROI calculation**" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 14: "**Why we need this:** Our savings calculation assumes 3.3M€ - if different, all ROI projections must be recalculated." → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 188: "[ ] Positive feedback (when received):" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 230: "**Why we ask:** If you say "impossible," the whole ROI model fails. If you say "easily 40%," we're being conservative." → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 291: "[ ] What's minimum ROI to approve? __________ K€/year" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 325: "1. Recalculate ROI with YOUR numbers (not estimates)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 341: "> "Gedimat affrètement costs ~120K€/an, baseline service 88%, NPS ~35," → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 342: "> estimated savings 50K€/year with 40/30/20/10 scoring model. ROI 10×"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/GEDIMAT_DATA_VALIDATION_FORM.md: line 350: "> **Verified ROI: 11.3× \| Payback: 5.2 weeks**"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 8: "**What was audited:** All unsourced financial claims in Gedimat dossier (50K€, 5K€, 10×, ROI, baselines, NPS)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 8: "**What was audited:** All unsourced financial claims in Gedimat dossier (50K€, 5K€, 10×, ROI, baselines, NPS)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 31: "- Action plan with templates" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 45: "- Response template with calculations" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 73: "(50K€, 5K€, 10× ROI, baselines = ALL UNSOURCED = FATAL)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 73: "(50K€, 5K€, 10× ROI, baselines = ALL UNSOURCED = FATAL)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 90: "\| 💣 1 \| `if_ttt_audit.md:39` \| "ROI 10×" \| Built on two unsourced numbers \| DOSSIER DIES HERE \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 91: "\| 💣 2 \| `ENHANCEMENT:263` \| "50K€ gains" \| From thin air \| ROI completely wrong \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 92: "\| 💣 3 \| `ENHANCEMENT:306` \| "30K€/quarter baseline" \| No invoices \| All improvements invalid \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 96: "\| 💣 7 \| `ENHANCEMENT:251` \| "88% service baseline" \| Inferred, not measured \| Impact calculation wrong \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 208: "- 10× ROI: DERIVED FROM UNSOURCED NUMBERS" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 209: "- 30K€ baseline: NO INVOICES" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 233: "2. You say: "Estimated, based on benchmarks"" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 265: "**Next milestone:** Decision on Option A/B/C + stakeholder notification" → Remplacer "milestone" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/README_AUDIT.md: line 265: "**Next milestone:** Decision on Option A/B/C + stakeholder notification" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 12: "- 8 CRITICAL risk claims (ROI, costs, baselines, payback)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 12: "- 8 CRITICAL risk claims (ROI, costs, baselines, payback)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 13: "- 7 HIGH risk benchmarks (unverified links)" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 26: "**Purpose:** High-level "credibility bombs" explanation for stakeholders" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 29: "- Phantom ROI (10×)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 31: "- 30K€ baseline (invented)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 35: "- 88% baseline (invisible audit)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 38: "- Action Plan (Step 1-3 with templates)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 51: "- High-risk baselines (4 metrics)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 52: "- Sourced-but-questionable benchmarks" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 70: "- Section 3: Customer Satisfaction (NPS survey template)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 93: "- QUICK_REFERENCE for stakeholder briefing" → Remplacer "stakeholder" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 116: "**Result:** Scoring spreadsheet, NPS template, communication scripts usable now" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 117: "**Caveat:** Do NOT cite "50K€ savings" or "ROI 10×" in presentations" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 123: "- Keep current dossier for tool templates only" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 134: "\| 5K€ investment \| NO SOURCE \| ROI = garbage \| Itemize actual costs \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 135: "\| 10× ROI \| DERIVED \| Built on two unsourced numbers \| Recalculate with real data \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 142: "If Gedimat PDG asks: "Where did you get these numbers?" and you say "estimated" or "benchmarks," he'll say: **"Show me YOUR invoices, not industry averages."**" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/v3_deployment/audit/AUDIT_INDEX.md: line 227: "**Primary Issues:** 8 critical unsourced financial claims (50K€, 5K€, 10×, baselines, assumptions)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 15: "- **C1:** Investissement WMS/ROI dépend croissance revenue inconnue (€50-150k décision bloquée)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 24: "**ROI Investissement Data:** 15-25x (évite erreurs budget majeures)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 28: "## CONTRADICTION C1: INVESTISSEMENT WMS/ROI" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 34: "- ROI supposé 15-24 mois (Pass 4 estimé, non-validé)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 35: "- MAIS: ROI dépend croissance annuelle revenue → **INCONNUE COMPLÈTE**" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 40: "- IF croissance >15% → WMS ROI 18 mois ✅" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 41: "- IF croissance 5-10% → WMS ROI 36+ mois ❌" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 53: "\| **Prévision croissance 2026-2027** \| Forecast volume clients (nouveaux + churn) \| Modélisation ROI \| Zéro = "stasis assumed" \| Entretiens clients 30+ \| forecasts commerciaux \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 57: "\| **Benchmarks WMS small logistics** \| Durée ROI payback petit réseau 3-5 dépôts \| Réalité vs théorie \| Pass 4 "15-24 mois" estimé \| Cas études Odoo/Cegid users 3-5 dépôts \|" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 69: "├─ 1. Extrait comptes: Revenue 2024 full year = baseline" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 72: "├─ 4. Flag: Si croissance <5% → alerte élevée (WMS unlikely ROI)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 117: "│   └─ Coûts setup? (€20-40k impact ROI total)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 122: "├─ 3 dépôts stasis: WMS ROI marginal (Excel suffit)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 132: "Coûts: €50 (timesheet app simple ou Excel template)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 167: "│   ├─ "ROI payback timeline observé?"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 171: "├─ 3. Synthèse: benchmarks réels" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 175: "├─ Best case: WMS ROI 18 mois (scaling operations, automation high)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 176: "├─ Real case: WMS ROI 24-30 mois (learning curve, change management)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 177: "└─ Worst case: WMS ROI 36+ mois (culture resistance, integration delays)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 212: "└─ WMS benchmarks: Start 5 interviews Agent 4" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 217: "├─ WMS benchmarks: Finish 10 interviews, synthesis report" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 235: "\| WMS benchmarks \| €300 (calls/trial) \| 20h (Agent 4 interviews + report) \| €500 \| €800 \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 244: "\| **Comptable** \| Finance \| Extract 2024-2025 revenue data, certify baseline \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 246: "\| **Agent 4 (IT)** \| Technologie \| WMS benchmarks (interviews 10 users), API audit CRM, synthesis report \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 255: "Decision Point 1: CROISSANCE RÉELLE 2025-2026?" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 262: "│     │  ├─ Expected ROI: 20-24 mois" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 274: "│  │  │  ├─ ALORS: PILOT WMS Q2 2026 (prove ROI before full commit)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 275: "│  │  │  ├─ Pilot: 1 dépôt + Angélique workflow, 6 months" → Remplacer "workflow" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 276: "│  │  │  ├─ Gate: IF pilot ROI >18 mois → full deploy" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 277: "│  │  │  └─ Gate: IF pilot ROI >24 mois → abandon WMS, stay Excel/TMS" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 304: "│  └─ WMS benchmarks ROI <24 mois" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 304: "│  └─ WMS benchmarks ROI <24 mois" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 309: "│  ├─ Pilot 6 mois (prove ROI before full commit)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 327: "├─ CRM baseline health score Excel" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 339: "├─ Team: "Phase 0 Excel essential BEFORE WMS, prove ROI"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 387: "\| **Point.P/Leroy urgence %** \| Benchmark: competitor urgence demand % \| Realistic market baseline \| Zéro (assumed 60% typical) \| Research OR contact users \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 419: "│   ├─ Result: "Urgence réelle baseline = X%"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 430: "└─ "Urgence réelle baseline = X% (confiance 90%), not 70-80% estimate"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 517: "└─ 3. Finding: Realistic market urgence baseline" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 525: "└─ If benchmark <50%: Gedimat likely over-estimating" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 574: "└─ Final: "Urgence réelle baseline = X% (confiance 85%)"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 629: "├─ ROI Improvement: Consolidation + milkrun 35-40% gain (vs 15-20% if 70% urgence)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 721: "├─ Team: "Urgence baseline audit in progress, tier calibration coming"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 735: "**Après Données:** 85% (CRM + phone + benchmark triangulation)" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 752: "- Decision WMS/assistant/SMS investment = ROI dépend churn réel" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 753: "- IF perte <€5k/an: Communication investment ROI <100% (not justified)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 754: "- IF perte >€15k/an: Communication investment ROI 500%+ (URGENT)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 764: "\| **Clients perdus 2024-2025** \| List formelle: qui parti, quand, pourquoi? \| Churn rate baseline \| "Y disparaît" anecdotal \| CRM audit: 100% client coverage \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 766: "\| **Churn rate %** \| % annual customer loss vs baseline \| Metric benchmarking \| Zéro mesure \| Calculate: Lost/Total year-start \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 766: "\| **Churn rate %** \| % annual customer loss vs baseline \| Metric benchmarking \| Zéro mesure \| Calculate: Lost/Total year-start \|" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 781: "├─ 1. CRM extract: All clients 2024 année complète (baseline)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 803: "├─ Churn rate baseline (expected 8-12% based benchmarks)" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 803: "├─ Churn rate baseline (expected 8-12% based benchmarks)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 829: "│   └─ "Merci beaucoup pour feedback!"" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 887: "├─ Penalty baseline (actual €Y per retard, not €500-5k range)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 890: "└─ Insight: "Retard = €X cost, premium service delivery = ROI justified?"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 896: "│  → Service investment (€15-20k) ROI justified" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 934: "└─ ROI focus: Communication/NPS investment target VIPs first" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1028: "│  ├─ Communication ROI: Lower priority investment (nice-to-have)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1034: "│  ├─ Conclusion: Communication investment justified (15-25x ROI)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1055: "│  ├─ → ROI: Every prevented retard = client retention" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1056: "│  └─ → Confidence: Service fixes have clear ROI" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1086: "│  ├─ → ROI: Premium service infrastructure less justified economically" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1091: "│  ├─ → Insight: "Retard = real cost, prevention ROI positive"" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1092: "│  ├─ → ROI: Service improvement investment (€15-20k) justified" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1098: "├─ → ROI: Premium service infrastructure URGENT" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1111: "│  ├─ → ROI: High (recover €50-100k+ revenue if successful)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1139: "├─ NPS investment justified IF churn >10% (ROI clear)" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1140: "├─ Communication ROI: 15-25x IF target churn reduction 2-3%" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1154: "1. ASSUME Moderate Churn (10-12% baseline)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1160: "├─ NPS baseline survey (start week 1): 50 clients" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1199: "- Scénario B ROI dépend Médiafret capacity + reliability SLA" → Remplacer "ROI" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1274: "│   │  ├─ "Current tarifs 2025: €/tonne baseline vs urgence premium?"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1282: "│   │  ├─ "Timeline: Can be ready January or need lead time?"" → Remplacer "lead time" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1292: "│      ├─ "From Médiafret: room improve, any feedback?"" → Remplacer "feedback" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1373: "│   └─ Average cost: €/shipment baseline" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1382: "├─ Médiafret cost baseline (€/shipment average)" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1386: "└─ Negotiation baseline: "We pay €X average, propose €Y master contract"" → Remplacer "baseline" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1402: "├─ Documentation: Legal prepare contract template (2-3 days)" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1417: "\| Transporteur benchmark \| €200 \| 15h (Agent 4 + Angélique) \| €300 \| €500 \|" → Remplacer "benchmark" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1419: "\| Legal contract template \| €200 \| 8h (Legal) \| €200 \| €400 \|" → Remplacer "template" par l’équivalent FR.
- gedimat_gpt5pro_package/evidence_dossier/PASS6_DEBUG4_TYPE_C_DATA_COLLECTION_PLANS.md: line 1427: "\| **Agent 7 (Juridique)** \| Legal \| Contract review, SLA template draft, negotiation legal terms \|" → Remplacer "template" par l’équivalent FR.

## Overall French Quality: ❌ FAIL (>5)

---
## QG6 GAPS
# CRITICAL GAPS IDENTIFIED

## OVERALL COMPLETENESS: 0 / 5 éléments critiques manquants

---
## QG7 LATEX SPEC
# LATEX TYPESETTING SPECIFICATIONS

- Document: \documentclass[12pt,a4paper]{report}, \usepackage[french]{babel}, \usepackage{pgfgantt}
- Sections: \chapter (Résumé Exécutif), \section (2–10), \appendix (Annexes)
- Références: BibTeX (adeo2023, kingfisher2023, saintgobain2023)
- Diagrammes: Flux logistique (TikZ), Arbre de décision (Graphviz/TikZ), Gantt 90 j (pgfgantt)


---
## ANNEXE X DECISION RULES
# Annexe X — Règles de décision
- Priorités: 1) Urgence client; 2) Proximité km; 3) Coût interne (navette)
- Seuils: ≤10 t interne; >10 t affrètement; Δ>15 km = proximité stricte
- Dérogations: urgence, contrainte fournisseur, anomalie de coût (journalisées)


---
## ANNEXE Y ALERTING SLA
# Annexe Y — Alertes & SLA
- Champs: promised_delivery_date, supplier_ack_date, customer_urgency_flag, pickup_confirmed_timestamp, depot_assigned, exception_reason
- SLA: ARC/ACK ≤48 h; pickup J‑1 16:00; respect fenêtre de livraison
- Alertes: ARC/ACK manquant; risque retard J‑1; pickup non confirmé; urgence client
- Pseudo‑requêtes SQL: cf. dossier (exemples fournis)


---
## ANNEXE Z COST MODEL README
# Annexe Z — Modèle de coûts (formules, pas de chiffres)
