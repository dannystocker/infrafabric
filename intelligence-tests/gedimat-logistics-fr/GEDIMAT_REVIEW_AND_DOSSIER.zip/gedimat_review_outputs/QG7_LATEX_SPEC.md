# LATEX TYPESETTING SPECIFICATIONS

- Document: \documentclass[12pt,a4paper]{report}, \usepackage[french]{babel}, \usepackage{pgfgantt}
- Sections: \chapter (Résumé Exécutif), \section (2–10), \appendix (Annexes)
- Références: BibTeX (adeo2023, kingfisher2023, saintgobain2023)
- Diagrammes: Flux logistique (TikZ), Arbre de décision (Graphviz/TikZ), Gantt 90 j (pgfgantt)
